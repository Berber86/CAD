import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CheckCircle2, Eye, Loader2, Map as MapIcon, Rocket, Sparkles, Users, X, AlertTriangle, Info } from "lucide-react";
import Header, { type StepState } from "./components/Header";
import SourcePanel, { type SourceMode } from "./components/SourcePanel";
import ResultPanel, { type ResultTab } from "./components/ResultPanel";
import CadCanvas from "./components/CadCanvas";
import SourceView from "./components/SourceView";
import SettingsDrawer from "./components/SettingsDrawer";
import { ConflictBanner, DoubtDialog, ShortcutsModal } from "./components/Dialogs";
import { Badge, Button, Segmented } from "./components/ui";
import { buildModel, fmtBearing, fmtLen, nextNeighbor, parseLegal, runChecks, type Check, type Model, type Neighbor } from "./lib/geo";
import { DEFAULT_SETTINGS, type LogEntry, type PassResult, type Photo, type Settings } from "./lib/types";
import { SAMPLE_OK, SAMPLE_TYPO } from "./lib/samples";
import { cn } from "./utils/cn";

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));
const now = () => new Date().toLocaleTimeString("ru-RU", { hour12: false });

function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem("tsai-settings");
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return DEFAULT_SETTINGS;
}

/** Демо-«ошибка прочтения» второго прохода: меняет последнюю цифру минут (0↔8) в румбе стороны #1 */
function variantText(src: string, m: Model) {
  const s = m.segs[0];
  const slice = src.slice(s.start, s.end).replace(/(\d)(\s*['′])/, (_x, d, q) => String((+d + 8) % 10) + q);
  return src.slice(0, s.start) + slice + src.slice(s.end);
}

export default function App() {
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [mode, setMode] = useState<SourceMode>("text");
  const [text, setText] = useState(SAMPLE_OK);
  const [pdfName, setPdfName] = useState<string | null>(null);
  const [pages, setPages] = useState("все");
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [photoIdx, setPhotoIdx] = useState(0);

  const [model, setModel] = useState<Model | null>(null);
  const [analyzedSrc, setAnalyzedSrc] = useState("");
  const [neighbors, setNeighbors] = useState<Neighbor[]>([]);
  const [conflict, setConflict] = useState<PassResult[] | null>(null);
  const [retrying, setRetrying] = useState(false);
  const [consensus, setConsensus] = useState<string | null>(null);
  const demoConflict = useRef(true);

  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<{ label: string; state: "wait" | "run" | "done" }[]>([]);
  const [drawing, setDrawing] = useState(false);
  const [drawn, setDrawn] = useState(false);
  const [acad, setAcad] = useState(true);

  const [centerTab, setCenterTab] = useState<"scheme" | "source">("scheme");
  const [rightTab, setRightTab] = useState<ResultTab>("sheet");
  const [hoverSide, setHoverSide] = useState<number | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [keysOpen, setKeysOpen] = useState(false);
  const [doubt, setDoubt] = useState(false);

  const [log, setLog] = useState<LogEntry[]>([{ t: now(), level: "info", msg: "Программа запущена. Вставьте описание и нажмите Ctrl+Enter." }]);
  const [tokens, setTokens] = useState(0);
  const [toast, setToast] = useState<{ msg: string; tone: "ok" | "warn" | "err" | "info" } | null>(null);

  const toastTimer = useRef(0);
  const pdfInput = useRef<HTMLInputElement>(null);
  const photoInput = useRef<HTMLInputElement>(null);

  const addLog = useCallback((msg: string, level: LogEntry["level"] = "info") => setLog((l) => [...l, { t: now(), level, msg }]), []);
  const showToast = useCallback((msg: string, tone: "ok" | "warn" | "err" | "info" = "info") => {
    setToast({ msg, tone });
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 3600);
  }, []);

  const checks = useMemo<Check[]>(() => (model ? runChecks(model) : []), [model]);
  const bad = checks.filter((c) => c.level !== "ok");
  const suspect = useMemo(() => Array.from(new Set(bad.flatMap((c) => c.sides))), [bad]);
  const textHeight = 0.9 * (settings.scale / 16);
  const keysReady = Object.values(settings.keys).filter((k) => k.trim()).length;
  const sourceReady = mode === "text" ? !!text.trim() : mode === "pdf" ? !!pdfName : photos.length > 0;
  const stale = !!model && mode === "text" && text !== analyzedSrc;

  // ─────────── Разбор ───────────
  const finishAnalysis = (src: string, passes: number) => {
    const m = buildModel(parseLegal(src));
    if (!m) {
      setModel(null);
      addLog("Не найдено ни одной стороны (нужен румб и длина в футах)", "err");
      showToast("Не удалось найти стороны участка", "err");
      return;
    }
    setAnalyzedSrc(src);
    setModel(m);
    setDrawn(false);
    setCenterTab("scheme");
    addLog(`Разобрано сторон: ${m.segs.length}; Closure Error = ${m.closure.toFixed(3)} ft; площадь ${Math.round(m.area).toLocaleString("en-US")} sq ft`, m.closure <= 0.01 ? "ok" : "warn");

    if (passes >= 2 && demoConflict.current) {
      const vt = variantText(src, m);
      if (vt !== src) {
        const m2 = buildModel(parseLegal(vt))!;
        const slots = settings.slots;
        const mk = (i: number, t: string, mm: Model, other: Model): PassResult => ({
          slot: i,
          label: `Проход #${i + 1}`,
          model: slots[i].model,
          closure: mm.closure,
          text: t,
          diffs: t === src ? [] : [{ side: 0, field: "румб", mine: fmtBearing(mm.segs[0]), other: fmtBearing(other.segs[0]) }],
        });
        const list: PassResult[] = [mk(0, src, m, m2), mk(1, vt, m2, m)];
        if (passes === 3) list.push(mk(2, src, m, m2));
        // у «эталона» покажем, чем он отличается от оппонента
        list.forEach((p) => { if (p.text === src && p.diffs.length === 0) p.diffs = [{ side: 0, field: "румб", mine: fmtBearing(m.segs[0]), other: fmtBearing(m2.segs[0]) }]; });
        setConflict(list);
        setConsensus(null);
        setRightTab("sheet");
        addLog(`Проходы расходятся: сторона #1, румб ${fmtBearing(m.segs[0])} ≠ ${fmtBearing(m2.segs[0])}`, "warn");
        showToast("Проходы разошлись — выберите правильный", "warn");
        return;
      }
    }
    setConflict(null);
    if (passes >= 2) {
      setConsensus(`${passes}/${passes}`);
      addLog(`Консенсус ${passes}/${passes}: все проходы прочитали одинаково`, "ok");
    } else setConsensus(null);
    const bads = runChecks(m).filter((c) => c.level !== "ok").length;
    if (bads) { setRightTab("checks"); showToast(`Подозрительно: ${bads} — см. «Проверки»`, "warn"); }
    else showToast("Разбор завершён — всё сходится", "ok");
  };

  const analyze = async (ai: boolean) => {
    if (running) return;
    let src = text;
    if (mode !== "text" && !text.trim()) {
      src = SAMPLE_OK;
      setText(SAMPLE_OK);
      addLog(`Демо: файл «${mode === "pdf" ? pdfName : "фото"}» «прочитан» как пример`, "info");
    }
    if (!src.trim()) { showToast("Нет исходных данных", "warn"); return; }
    setConflict(null);
    if (!ai) {
      addLog("Быстрый разбор без ИИ (regex)");
      finishAnalysis(src, 1);
      setConsensus(null);
      return;
    }
    const n = settings.passes;
    const labels = Array.from({ length: n }, (_, i) => `Проход #${i + 1} · ${settings.slots[i].provider} / ${settings.slots[i].model}`);
    setRunning(true);
    setProgress(labels.map((label) => ({ label, state: "run" as const })));
    addLog(`Запуск ИИ-разбора: ${n} ${n === 1 ? "проход" : "прохода"} параллельно`);
    await Promise.all(
      labels.map(async (_, i) => {
        await delay(700 + i * 380);
        setProgress((p) => p.map((r, j) => (j === i ? { ...r, state: "done" } : r)));
      })
    );
    await delay(250);
    setRunning(false);
    setTokens((t) => t + n * (1800 + Math.floor(Math.random() * 900)));
    finishAnalysis(src, n);
  };

  const pickPass = (slot: number) => {
    if (!conflict) return;
    const pass = conflict[slot];
    const m = buildModel(parseLegal(pass.text));
    if (!m) return;
    setModel(m);
    setConflict(null);
    setConsensus(null);
    addLog(`Принят ${pass.label}; Closure Error = ${m.closure.toFixed(3)} ft`, m.closure <= 0.01 ? "ok" : "warn");
    showToast(`Принят ${pass.label}`, "ok");
  };

  const retryConflict = async () => {
    setRetrying(true);
    addLog("Повторный раунд с фокусом на спорные поля…");
    await delay(1500);
    setTokens((t) => t + 2400);
    demoConflict.current = false;
    setRetrying(false);
    const m = buildModel(parseLegal(analyzedSrc))!;
    setModel(m);
    setConflict(null);
    setConsensus(`${settings.passes}/${settings.passes}`);
    addLog(`Консенсус: модели сошлись на ${fmtBearing(m.segs[0])}`, "ok");
    showToast("Модели пришли к единому мнению", "ok");
  };

  // ─────────── Исправление / AutoCAD ───────────
  const applyFix = (c: Check) => {
    if (!c.fix || !model) return;
    const s = model.segs[c.fix.side];
    const nt = analyzedSrc.slice(0, s.lenStart) + c.fix.to.toFixed(2) + analyzedSrc.slice(s.lenEnd);
    setText(nt);
    setAnalyzedSrc(nt);
    const m = buildModel(parseLegal(nt));
    setModel(m);
    setDoubt(false);
    addLog(`Применено исправление: сторона #${c.fix.side + 1} ${c.fix.from.toFixed(2)}' → ${c.fix.to.toFixed(2)}'`, "ok");
    showToast("Исправление применено", "ok");
  };

  const focusRound = async () => {
    addLog("Фокус-раунд LLM по зоне внимания…");
    await delay(1400);
    setTokens((t) => t + 1300);
    const f = bad.find((c) => c.fix);
    const msg = f?.fix
      ? `Модели перечитали сторону #${f.fix.side + 1}: в документе действительно написано ${f.fix.from.toFixed(2)}'. Цифру не подгоняем — решайте сами: оставить или исправить.`
      : "Модели подтвердили прочтение без изменений.";
    addLog(msg, "info");
    return msg;
  };

  const drawAcad = async (force = false) => {
    if (!model) { showToast("Сначала разберите описание", "warn"); return; }
    if (conflict) { showToast("Сначала разрешите расхождение проходов", "warn"); return; }
    if (!acad) { showToast("AutoCAD не найден — запустите его и откройте DWG", "err"); addLog("AutoCAD не найден", "err"); return; }
    if (settings.askOnDoubt && bad.length && !force) { setDoubt(true); return; }
    setDoubt(false);
    setDrawing(true);
    addLog("Отправка в AutoCAD…");
    await delay(1500);
    setDrawing(false);
    setDrawn(true);
    const lines = model.segs.length + neighbors.length * 4;
    addLog(`AutoCAD: построено ${lines} отрезков LINE, ${model.segs.length} подписей румбов, POB и улицы`, "ok");
    showToast(`Готово: ${lines} отрезков LINE в чертеже`, "ok");
  };

  // ─────────── Соседи ───────────
  const addNeighbor = () => {
    if (!model) return;
    const n = nextNeighbor(model, neighbors);
    if (!n) return;
    setNeighbors((l) => [...l, n]);
    setRightTab("neighbors");
    setCenterTab("scheme");
    setDrawn(false);
    addLog(`${n.name}: ${n.title}`, n.level === "warn" ? "warn" : "ok");
    if (n.level === "warn") showToast("Сверка нашла расхождение на общей меже", "warn");
  };

  // ─────────── Файлы ───────────
  const onPhotos = (files: FileList | null) => {
    if (!files?.length) return;
    const add = Array.from(files).map((f, i) => ({ id: Date.now() + i, name: f.name, url: URL.createObjectURL(f), rot: 0 }));
    setPhotos((p) => [...p, ...add]);
    setPhotoIdx(photos.length);
    setMode("photo");
    addLog(`Загружено фото: ${add.length}`);
  };
  const onPdf = (files: FileList | null) => {
    if (!files?.[0]) return;
    setPdfName(files[0].name);
    setMode("pdf");
    addLog(`Загружен PDF: ${files[0].name}`);
  };
  const rotatePhoto = (d: number) => setPhotos((ps) => ps.map((p, i) => (i === photoIdx ? { ...p, rot: p.rot + d } : p)));
  const removePhoto = () => {
    setPhotos((ps) => ps.filter((_, i) => i !== photoIdx));
    setPhotoIdx((i) => Math.max(0, i - 1));
  };

  // ─────────── Копирование ───────────
  const copy = async (s: string, ok: string) => {
    try { await navigator.clipboard.writeText(s); showToast(ok, "ok"); } catch { showToast("Буфер обмена недоступен", "err"); }
  };
  const copySheet = () => {
    if (!model) return;
    const rows = model.segs.map((s, i) => `#${i + 1}  ${fmtBearing(s)}  ${fmtLen(s.len)}`).join("\n");
    const diag = checks.map((c) => `${c.level === "ok" ? "✓" : "⚠"} ${c.title} — ${c.detail}`).join("\n");
    const nb = neighbors.length ? "\n\nСверка с соседями:\n" + neighbors.map((n) => `${n.name}: ${n.title}`).join("\n") : "";
    copy(`${rows}\n\nClosure Error: ${model.closure.toFixed(3)} ft\nПлощадь: ${Math.round(model.area)} sq ft\nПериметр: ${model.perimeter.toFixed(2)} ft\n\n${diag}${nb}`, "Ведомость скопирована");
  };
  const copyAct = () => copy(neighbors.map((n) => `${n.name} (${n.width}'): ${n.title}\n${n.detail}`).join("\n\n"), "Акт сверки скопирован");

  const saveSettings = () => {
    localStorage.setItem("tsai-settings", JSON.stringify({ ...settings, keys: DEFAULT_SETTINGS.keys, pin: "" }));
    addLog("Настройки сохранены", "ok");
    showToast("Настройки сохранены", "ok");
  };

  // ─────────── Горячие клавиши ───────────
  const hk = useRef({ analyze, drawAcad, saveSettings });
  hk.current = { analyze, drawAcad, saveSettings };
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const c = e.ctrlKey || e.metaKey;
      if (c && e.key === "Enter") { e.preventDefault(); hk.current.analyze(true); }
      else if (e.key === "F5") { e.preventDefault(); hk.current.drawAcad(); }
      else if (c && e.key.toLowerCase() === "o") { e.preventDefault(); pdfInput.current?.click(); }
      else if (c && e.key.toLowerCase() === "i") { e.preventDefault(); photoInput.current?.click(); }
      else if (c && e.key.toLowerCase() === "s") { e.preventDefault(); hk.current.saveSettings(); }
      else if (e.key === "Escape") { setSettingsOpen(false); setKeysOpen(false); setDoubt(false); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  // ─────────── Шаги ───────────
  const steps: { label: string; state: StepState }[] = [
    { label: "Источник", state: sourceReady ? "done" : "active" },
    { label: "Разбор", state: model ? "done" : running || sourceReady ? "active" : "todo" },
    { label: "Проверка", state: !model ? "todo" : conflict || bad.length ? "active" : "done" },
    { label: "AutoCAD", state: drawn ? "done" : model && !conflict ? "active" : "todo" },
  ];

  const status = running
    ? { tone: "blue", text: "Идёт ИИ-разбор…" }
    : drawing
    ? { tone: "blue", text: "Отправка в AutoCAD…" }
    : conflict
    ? { tone: "amber", text: "Проходы расходятся — нужно ваше решение" }
    : !model
    ? { tone: "slate", text: "Готов к работе" }
    : bad.length
    ? { tone: "amber", text: `Разобрано · подозрительно: ${bad.length} · Closure ${model.closure.toFixed(3)} ft` }
    : drawn
    ? { tone: "green", text: "Участок построен в AutoCAD" }
    : { tone: "green", text: `Разобрано · всё сходится · Closure ${model.closure.toFixed(3)} ft` };

  const dot = { blue: "bg-blue-400 animate-pulse", amber: "bg-amber-400", green: "bg-emerald-400", slate: "bg-slate-500" }[status.tone];

  return (
    <div className="flex h-screen min-w-[1100px] flex-col overflow-hidden bg-[#0a111a] font-sans text-slate-200 antialiased">
      <Header
        steps={steps}
        scale={settings.scale}
        onScale={(s) => setSettings({ ...settings, scale: s })}
        acad={acad}
        onToggleAcad={() => setAcad((a) => !a)}
        onSettings={() => setSettingsOpen(true)}
        onKeys={() => setKeysOpen(true)}
        keysReady={keysReady}
      />

      <main className="grid min-h-0 flex-1 grid-cols-[320px_minmax(0,1fr)_320px] xl:grid-cols-[360px_minmax(0,1fr)_380px]">
        <SourcePanel
          mode={mode}
          setMode={setMode}
          text={text}
          setText={setText}
          onSample={(k) => { setText(k === "ok" ? SAMPLE_OK : SAMPLE_TYPO); setMode("text"); demoConflict.current = true; }}
          pdfName={pdfName}
          pages={pages}
          setPages={setPages}
          onPickPdf={() => pdfInput.current?.click()}
          onPickPhotos={() => photoInput.current?.click()}
          photos={photos}
          photoIdx={photoIdx}
          setPhotoIdx={setPhotoIdx}
          rotatePhoto={rotatePhoto}
          removePhoto={removePhoto}
          settings={settings}
          setSettings={setSettings}
          openSettings={() => setSettingsOpen(true)}
          running={running}
          progress={progress}
          onAnalyze={analyze}
          stale={stale}
        />

        {/* Центр */}
        <section className="flex min-h-0 min-w-0 flex-col">
          <div className="flex h-12 shrink-0 items-center gap-3 border-b border-slate-800 bg-[#0d1622] px-4">
            <Segmented
              value={centerTab}
              onChange={setCenterTab}
              options={[
                { value: "scheme", label: <><MapIcon size={14} /> Схема CAD</> },
                { value: "source", label: <><Eye size={14} /> Исходник</> },
              ]}
            />
            <div className="ml-auto flex items-center gap-3 text-[11px] text-slate-400">
              {consensus && <Badge tone="green"><Sparkles size={11} /> Консенсус {consensus}</Badge>}
              {model && <Badge tone={model.closure <= 0.01 ? "green" : "amber"}>Closure {model.closure.toFixed(3)} ft</Badge>}
              <span className="hidden items-center gap-3 2xl:flex">
                <Legend color="#f87171" label="Участок" />
                <Legend color="#22d3ee" label="Сосед" />
                <Legend color="#64748b" label="Улицы" dashed />
                <Legend color="#fbbf24" label="Внимание" />
              </span>
            </div>
          </div>

          {conflict && <ConflictBanner passes={conflict} busy={retrying} onPick={pickPass} onRetry={retryConflict} />}

          <div className="relative min-h-0 flex-1">
            {centerTab === "scheme" ? (
              <CadCanvas
                model={model}
                neighbors={neighbors}
                suspect={suspect}
                hoverSide={hoverSide}
                onHoverSide={setHoverSide}
                scaleText={`1"=${settings.scale}' · текст ${textHeight.toFixed(2)}`}
              />
            ) : (
              <SourceView text={text} model={model} photo={photos[photoIdx]} usePhoto={mode === "photo"} pdfName={pdfName} hoverSide={hoverSide} onHoverSide={setHoverSide} suspect={suspect} />
            )}
          </div>
        </section>

        <ResultPanel
          tab={rightTab}
          setTab={setRightTab}
          model={model}
          checks={checks}
          neighbors={neighbors}
          hoverSide={hoverSide}
          onHoverSide={setHoverSide}
          log={log}
          tokens={tokens}
          onCopy={copySheet}
          onApplyFix={applyFix}
          onAddNeighbor={addNeighbor}
          onClearNeighbors={() => setNeighbors([])}
          onCopyAct={copyAct}
          textHeight={textHeight}
          scale={settings.scale}
          onClearLog={() => setLog([])}
          onRecheck={async () => { const m = await focusRound(); showToast(m, "info"); }}
        />
      </main>

      {/* Нижняя панель действий */}
      <footer className="flex h-16 shrink-0 items-center gap-4 border-t border-slate-800 bg-[#0f1926] px-4">
        <div className="flex min-w-0 items-center gap-2.5 text-[13px]">
          <span className={cn("h-2 w-2 shrink-0 rounded-full", dot)} />
          <span className="truncate text-slate-300">{status.text}</span>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Button variant="secondary" disabled={!model} onClick={addNeighbor} icon={<Users size={15} />}>Сверка с соседями</Button>
          <Button
            variant={drawn ? "success" : "primary"}
            size="lg"
            disabled={!model || drawing || !!conflict}
            onClick={() => drawAcad()}
            icon={drawing ? <Loader2 size={16} className="animate-spin" /> : drawn ? <CheckCircle2 size={16} /> : <Rocket size={16} />}
            className="min-w-[280px]"
          >
            {drawing ? "Строю…" : drawn ? "Перечертить в AutoCAD" : neighbors.length ? `Начертить участок + ${neighbors.length} сосед.` : "Начертить участок в AutoCAD"}
            <span className="ml-1 rounded bg-black/25 px-1.5 text-[10px] font-semibold">F5</span>
          </Button>
        </div>
      </footer>

      <SettingsDrawer open={settingsOpen} onClose={() => setSettingsOpen(false)} s={settings} setS={setSettings} onSave={saveSettings} />
      {keysOpen && <ShortcutsModal onClose={() => setKeysOpen(false)} />}
      {doubt && (
        <DoubtDialog
          checks={bad}
          onClose={() => setDoubt(false)}
          onKeep={() => { addLog("Оставлено как в документе", "info"); drawAcad(true); }}
          onApply={applyFix}
          onFocus={focusRound}
        />
      )}

      <input ref={pdfInput} type="file" accept="application/pdf" hidden onChange={(e) => { onPdf(e.target.files); e.target.value = ""; }} />
      <input ref={photoInput} type="file" accept="image/*" multiple hidden onChange={(e) => { onPhotos(e.target.files); e.target.value = ""; }} />

      {/* Тост */}
      {toast && (
        <div className="pointer-events-none fixed bottom-20 left-1/2 z-[70] -translate-x-1/2">
          <div
            className={cn(
              "pointer-events-auto flex max-w-xl items-start gap-2.5 rounded-xl border px-4 py-2.5 text-[13px] shadow-2xl backdrop-blur",
              toast.tone === "ok" && "border-emerald-500/40 bg-emerald-950/90 text-emerald-100",
              toast.tone === "warn" && "border-amber-500/40 bg-amber-950/90 text-amber-100",
              toast.tone === "err" && "border-red-500/40 bg-red-950/90 text-red-100",
              toast.tone === "info" && "border-slate-600 bg-slate-900/95 text-slate-100"
            )}
          >
            {toast.tone === "ok" ? <CheckCircle2 size={16} className="mt-0.5 shrink-0" /> : toast.tone === "info" ? <Info size={16} className="mt-0.5 shrink-0" /> : <AlertTriangle size={16} className="mt-0.5 shrink-0" />}
            <span>{toast.msg}</span>
            <button onClick={() => setToast(null)} className="ml-1 opacity-60 hover:opacity-100"><X size={14} /></button>
          </div>
        </div>
      )}
    </div>
  );
}

function Legend({ color, label, dashed }: { color: string; label: string; dashed?: boolean }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="inline-block w-4" style={{ borderTop: `2px ${dashed ? "dashed" : "solid"} ${color}` }} />
      {label}
    </span>
  );
}
