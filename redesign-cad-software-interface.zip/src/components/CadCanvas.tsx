import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Crosshair, Maximize2, Minus, Plus } from "lucide-react";
import { fmtBearing, fmtLen, sideNormal, type Model, type Neighbor, type Pt } from "../lib/geo";

type View = { k: number; ox: number; oy: number };

const C = {
  bg: "#0a111a",
  grid: "#132235",
  gridStrong: "#1b2f48",
  axisText: "#4d6381",
  prop: "#f87171",
  propFill: "rgba(248,113,113,0.10)",
  nb: "#22d3ee",
  nbFill: "rgba(34,211,238,0.07)",
  nbWarn: "#fbbf24",
  street: "#64748b",
  streetText: "#7dd3fc",
  tie: "#fbbf24",
  hover: "#fde047",
  label: "#6ee7b7",
  text: "#cbd5e1",
};

const NICE = [0.5, 1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000];
const niceStep = (minWorld: number) => NICE.find((n) => n >= minWorld) ?? 1000;

function distToSeg(p: Pt, a: Pt, b: Pt) {
  const dx = b.x - a.x, dy = b.y - a.y;
  const l2 = dx * dx + dy * dy || 1;
  let t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
}

type Props = {
  model: Model | null;
  neighbors: Neighbor[];
  suspect: number[];
  hoverSide: number | null;
  onHoverSide: (i: number | null) => void;
  scaleText: string;
};

export default function CadCanvas({ model, neighbors, suspect, hoverSide, onHoverSide, scaleText }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const cvRef = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState({ w: 800, h: 600 });
  const [view, setView] = useState<View>({ k: 3, ox: 100, oy: 400 });
  const [fitK, setFitK] = useState(3);
  const [mouse, setMouse] = useState<Pt | null>(null);
  const drag = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);

  // bbox всех объектов
  const bbox = useMemo(() => {
    const pts: Pt[] = [{ x: 0, y: 0 }];
    if (model) {
      pts.push(...model.pts);
      neighbors.forEach((n) => pts.push(...n.pts));
    }
    const xs = pts.map((p) => p.x), ys = pts.map((p) => p.y);
    return { x0: Math.min(...xs), x1: Math.max(...xs), y0: Math.min(...ys), y1: Math.max(...ys) };
  }, [model, neighbors]);

  const fit = useCallback(() => {
    const pad = 90;
    const bw = Math.max(bbox.x1 - bbox.x0, 20), bh = Math.max(bbox.y1 - bbox.y0, 20);
    const k = Math.min((size.w - pad * 2) / bw, (size.h - pad * 2) / bh);
    const cx = (bbox.x0 + bbox.x1) / 2, cy = (bbox.y0 + bbox.y1) / 2;
    setFitK(k);
    setView({ k, ox: size.w / 2 - cx * k, oy: size.h / 2 + cy * k });
  }, [bbox, size]);

  // размеры
  useEffect(() => {
    const el = wrapRef.current!;
    const ro = new ResizeObserver(() => setSize({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  // автоподгонка при смене модели
  const lastModel = useRef<Model | null>(null);
  useEffect(() => {
    if (lastModel.current !== model || neighbors.length) {
      fit();
      lastModel.current = model;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [model, neighbors.length, size.w, size.h]);

  const toWorld = useCallback((sx: number, sy: number): Pt => ({ x: (sx - view.ox) / view.k, y: (view.oy - sy) / view.k }), [view]);

  const zoomAt = useCallback(
    (sx: number, sy: number, factor: number) => {
      setView((v) => {
        const nk = Math.max(fitK * 0.6, Math.min(fitK * 10, v.k * factor));
        const f = nk / v.k;
        return { k: nk, ox: sx - (sx - v.ox) * f, oy: sy - (sy - v.oy) * f };
      });
    },
    [fitK]
  );

  // колесо (non-passive)
  useEffect(() => {
    const cv = cvRef.current!;
    const h = (e: WheelEvent) => {
      e.preventDefault();
      const r = cv.getBoundingClientRect();
      zoomAt(e.clientX - r.left, e.clientY - r.top, e.deltaY < 0 ? 1.15 : 1 / 1.15);
    };
    cv.addEventListener("wheel", h, { passive: false });
    return () => cv.removeEventListener("wheel", h);
  }, [zoomAt]);

  // ───────── рисование ─────────
  useEffect(() => {
    const cv = cvRef.current!;
    const dpr = window.devicePixelRatio || 1;
    cv.width = size.w * dpr;
    cv.height = size.h * dpr;
    const g = cv.getContext("2d")!;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.fillStyle = C.bg;
    g.fillRect(0, 0, size.w, size.h);

    const S = (p: Pt): [number, number] => [view.ox + p.x * view.k, view.oy - p.y * view.k];

    // сетка
    const step = niceStep(70 / view.k);
    const minor = step / 5;
    const wx0 = -view.ox / view.k, wx1 = (size.w - view.ox) / view.k;
    const wy1 = view.oy / view.k, wy0 = (view.oy - size.h) / view.k;
    g.lineWidth = 1;
    if (minor * view.k > 12) {
      g.strokeStyle = "rgba(19,34,53,0.55)";
      g.beginPath();
      for (let x = Math.ceil(wx0 / minor) * minor; x <= wx1; x += minor) { const [sx] = S({ x, y: 0 }); g.moveTo(Math.round(sx) + 0.5, 0); g.lineTo(Math.round(sx) + 0.5, size.h); }
      for (let y = Math.ceil(wy0 / minor) * minor; y <= wy1; y += minor) { const [, sy] = S({ x: 0, y }); g.moveTo(0, Math.round(sy) + 0.5); g.lineTo(size.w, Math.round(sy) + 0.5); }
      g.stroke();
    }
    g.strokeStyle = C.grid;
    g.beginPath();
    for (let x = Math.ceil(wx0 / step) * step; x <= wx1; x += step) { const [sx] = S({ x, y: 0 }); g.moveTo(Math.round(sx) + 0.5, 0); g.lineTo(Math.round(sx) + 0.5, size.h); }
    for (let y = Math.ceil(wy0 / step) * step; y <= wy1; y += step) { const [, sy] = S({ x: 0, y }); g.moveTo(0, Math.round(sy) + 0.5); g.lineTo(size.w, Math.round(sy) + 0.5); }
    g.stroke();
    // подписи осей
    g.fillStyle = C.axisText;
    g.font = "10px ui-monospace, SFMono-Regular, Menlo, monospace";
    g.textAlign = "center";
    for (let x = Math.ceil(wx0 / step) * step; x <= wx1; x += step) { const [sx] = S({ x, y: 0 }); g.fillText(String(Math.round(x * 100) / 100), sx, size.h - 8); }
    g.textAlign = "left";
    for (let y = Math.ceil(wy0 / step) * step; y <= wy1; y += step) { const [, sy] = S({ x: 0, y }); g.fillText(String(Math.round(y * 100) / 100), 8, sy - 4); }

    // оси через (0,0)
    const [zx, zy] = S({ x: 0, y: 0 });
    g.strokeStyle = C.gridStrong;
    g.beginPath(); g.moveTo(zx + 0.5, 0); g.lineTo(zx + 0.5, size.h); g.moveTo(0, zy + 0.5); g.lineTo(size.w, zy + 0.5); g.stroke();

    const textAlong = (txt: string, a: Pt, b: Pt, off: number, color: string, font: string, nrm: Pt, t = 0.5, bg = false) => {
      const [x1, y1] = S(a), [x2, y2] = S(b);
      let ang = Math.atan2(y2 - y1, x2 - x1);
      if (ang > Math.PI / 2 || ang < -Math.PI / 2) ang += Math.PI;
      const mx = x1 + (x2 - x1) * t + nrm.x * off, my = y1 + (y2 - y1) * t - nrm.y * off;
      g.save();
      g.translate(mx, my);
      g.rotate(ang);
      g.font = font;
      g.textAlign = "center";
      g.textBaseline = "middle";
      if (bg) {
        const w = g.measureText(txt).width + 10;
        g.fillStyle = "rgba(10,17,26,0.85)";
        g.fillRect(-w / 2, -9, w, 18);
      }
      g.fillStyle = color;
      g.fillText(txt, 0, 0);
      g.restore();
    };

    if (model) {
      const u = model.u;
      const nrm: Pt = { x: -u.y, y: u.x }; // влево от улицы
      // улицы
      const L = 4000;
      g.setLineDash([10, 6]);
      g.strokeStyle = C.street;
      g.lineWidth = 1.2;
      g.beginPath();
      let [a1, a2] = S({ x: -u.x * L, y: -u.y * L });
      let [b1, b2] = S({ x: u.x * L, y: u.y * L });
      g.moveTo(a1, a2); g.lineTo(b1, b2);
      [a1, a2] = S({ x: -nrm.x * L, y: -nrm.y * L });
      [b1, b2] = S({ x: nrm.x * L, y: nrm.y * L });
      g.moveTo(a1, a2); g.lineTo(b1, b2);
      g.stroke();
      g.setLineDash([]);

      // подписи улиц
      const mainA = { x: u.x * Math.max(model.tie * 0.5, 30), y: u.y * Math.max(model.tie * 0.5, 30) };
      textAlong(model.mainStreet, mainA, { x: mainA.x + u.x, y: mainA.y + u.y }, 14, C.streetText, "600 11px ui-sans-serif, system-ui, sans-serif", nrm, 0);
      textAlong(model.crossStreet, { x: nrm.x * 25, y: nrm.y * 25 }, { x: nrm.x * 26, y: nrm.y * 26 }, 14, C.streetText, "600 11px ui-sans-serif, system-ui, sans-serif", { x: u.x, y: u.y }, 0);

      // привязка crossing → POB
      if (model.tie > 0) {
        g.strokeStyle = C.tie;
        g.lineWidth = 1.4;
        g.setLineDash([2, 4]);
        g.beginPath();
        const [t1, t2] = S(model.crossing), [t3, t4] = S(model.pob);
        g.moveTo(t1, t2); g.lineTo(t3, t4);
        g.stroke();
        g.setLineDash([]);
        textAlong(`${model.tie.toFixed(2)}' to corner`, model.crossing, model.pob, -14, C.tie, "11px ui-monospace, monospace", nrm);
      }
    }

    // соседи
    neighbors.forEach((n) => {
      g.beginPath();
      n.pts.forEach((p, i) => { const [x, y] = S(p); i ? g.lineTo(x, y) : g.moveTo(x, y); });
      g.closePath();
      g.fillStyle = C.nbFill;
      g.fill();
      g.strokeStyle = C.nb;
      g.lineWidth = 1.6;
      g.stroke();
      const cx = n.pts.reduce((a, p) => a + p.x, 0) / 4, cy = n.pts.reduce((a, p) => a + p.y, 0) / 4;
      const [sx, sy] = S({ x: cx, y: cy });
      g.fillStyle = C.nb;
      g.font = "600 11px ui-sans-serif, system-ui, sans-serif";
      g.textAlign = "center";
      g.textBaseline = "middle";
      g.fillText(`NEIGHBOR #${n.id}`, sx, sy - 8);
      g.fillStyle = "#67a9b8";
      g.font = "10px ui-monospace, monospace";
      g.fillText(`${n.width}' wide`, sx, sy + 8);
      // стена
      if (n.level === "warn") {
        g.strokeStyle = C.nbWarn;
        g.lineWidth = 3;
        const [x1, y1] = S(n.pts[0]), [x2, y2] = S(n.pts[3]);
        g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke();
        const [mx, my] = S({ x: (n.pts[0].x + n.pts[3].x) / 2, y: (n.pts[0].y + n.pts[3].y) / 2 });
        g.fillStyle = "#1b1407"; g.fillRect(mx + 8, my - 9, 56, 18);
        g.fillStyle = C.nbWarn; g.font = "600 10px ui-monospace, monospace"; g.textAlign = "left";
        g.fillText("⚠ Δ∠ 8″", mx + 12, my);
      } else if (n.id > 1) {
        const [mx, my] = S({ x: (n.pts[0].x + n.pts[3].x) / 2, y: (n.pts[0].y + n.pts[3].y) / 2 });
        g.fillStyle = "#34d399"; g.font = "600 10px ui-monospace, monospace"; g.textAlign = "left";
        g.fillText("✓ межа", mx + 8, my);
      }
    });

    // основной участок
    if (model) {
      const n = model.segs.length;
      const closed = model.closure <= 0.01;
      const poly = closed ? model.pts.slice(0, n) : model.pts;
      g.beginPath();
      poly.forEach((p, i) => { const [x, y] = S(p); i ? g.lineTo(x, y) : g.moveTo(x, y); });
      g.closePath();
      g.fillStyle = C.propFill;
      g.fill();

      for (let i = 0; i < n; i++) {
        const a = model.pts[i], b = model.pts[i + 1];
        const [x1, y1] = S(a), [x2, y2] = S(b);
        const isHover = hoverSide === i;
        const isSus = suspect.includes(i);
        g.lineWidth = isHover ? 4 : 2.2;
        g.strokeStyle = isHover ? C.hover : isSus ? C.tie : C.prop;
        g.setLineDash(isSus && !isHover ? [8, 5] : []);
        g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke();
        g.setLineDash([]);
        const pxLen = Math.hypot(x2 - x1, y2 - y1);
        const nr = sideNormal(model, i);
        if (pxLen > 90) {
          textAlong(fmtBearing(model.segs[i]), a, b, 13, isHover ? C.hover : C.label, "11px ui-monospace, monospace", nr);
          textAlong(fmtLen(model.segs[i].len), a, b, -13, isHover ? C.hover : "#a7b6c9", "11px ui-monospace, monospace", nr);
        } else if (pxLen > 40) {
          textAlong(fmtLen(model.segs[i].len), a, b, 12, C.label, "10px ui-monospace, monospace", nr);
        }
        // номер стороны
        const [mx, my] = S({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
        const bx = mx - nr.x * 0 , by = my;
        g.fillStyle = isHover ? C.hover : isSus ? C.tie : "#1f2c3f";
        g.beginPath(); g.arc(bx, by, 8, 0, Math.PI * 2); g.fill();
        g.fillStyle = isHover || isSus ? "#0a111a" : "#9fb2c9";
        g.font = "600 9px ui-monospace, monospace"; g.textAlign = "center"; g.textBaseline = "middle";
        g.fillText(String(i + 1), bx, by + 0.5);
        if (isSus) {
          g.fillStyle = C.tie; g.font = "600 10px ui-sans-serif, sans-serif"; g.textAlign = "left";
          g.fillText(`⚠ #${i + 1}`, bx + 12, by - 10);
        }
      }
      // вершины
      model.pts.slice(0, n).forEach((p) => {
        const [x, y] = S(p);
        g.fillStyle = "#0a111a"; g.strokeStyle = C.prop; g.lineWidth = 1.6;
        g.fillRect(x - 3.5, y - 3.5, 7, 7); g.strokeRect(x - 3.5, y - 3.5, 7, 7);
      });
      // POB
      const [px, py] = S(model.pob);
      g.fillStyle = C.tie; g.beginPath(); g.arc(px, py, 5, 0, Math.PI * 2); g.fill();
      g.strokeStyle = C.tie; g.lineWidth = 1; g.beginPath(); g.arc(px, py, 10, 0, Math.PI * 2); g.stroke();
      g.fillStyle = C.tie; g.font = "700 11px ui-sans-serif, sans-serif"; g.textAlign = "left"; g.textBaseline = "middle";
      g.fillText("POB", px + 14, py - 10);
      // GAP
      if (!closed) {
        const e = model.pts[n];
        const [gx, gy] = S(e);
        g.strokeStyle = "#f59e0b"; g.lineWidth = 2; g.setLineDash([4, 3]);
        g.beginPath(); g.arc(gx, gy, 12, 0, Math.PI * 2); g.stroke(); g.setLineDash([]);
        g.fillStyle = "#f59e0b"; g.font = "700 11px ui-monospace, monospace"; g.textAlign = "left";
        g.fillText(`GAP ${model.closure.toFixed(2)}'`, gx + 18, gy - 14);
      }
    }

    // (0,0)
    g.strokeStyle = "#94a3b8"; g.lineWidth = 1.4;
    g.beginPath(); g.arc(zx, zy, 6, 0, Math.PI * 2); g.moveTo(zx - 10, zy); g.lineTo(zx + 10, zy); g.moveTo(zx, zy - 10); g.lineTo(zx, zy + 10); g.stroke();
    g.fillStyle = "#94a3b8"; g.font = "10px ui-monospace, monospace"; g.textAlign = "left"; g.textBaseline = "alphabetic";
    g.fillText("(0,0)", zx + 12, zy + 18);

    // Масштабная линейка
    const bar = niceStep(110 / view.k);
    const bpx = bar * view.k;
    const bx0 = 24, by0 = size.h - 40;
    g.strokeStyle = "#cbd5e1"; g.lineWidth = 2;
    g.beginPath(); g.moveTo(bx0, by0 - 5); g.lineTo(bx0, by0); g.lineTo(bx0 + bpx, by0); g.lineTo(bx0 + bpx, by0 - 5); g.stroke();
    g.fillStyle = "#cbd5e1"; g.font = "11px ui-monospace, monospace"; g.textAlign = "left";
    g.fillText(`${bar} ft`, bx0, by0 - 10);

    // Север
    const nx = size.w - 44, ny = 70;
    g.strokeStyle = "#e2e8f0"; g.fillStyle = "#e2e8f0"; g.lineWidth = 2;
    g.beginPath(); g.moveTo(nx, ny + 22); g.lineTo(nx, ny - 14); g.stroke();
    g.beginPath(); g.moveTo(nx, ny - 22); g.lineTo(nx - 6, ny - 10); g.lineTo(nx + 6, ny - 10); g.closePath(); g.fill();
    g.font = "700 12px ui-sans-serif, sans-serif"; g.textAlign = "center"; g.fillText("N", nx, ny + 38);
  }, [size, view, model, neighbors, suspect, hoverSide]);

  // ───────── мышь ─────────
  const onDown = (e: React.MouseEvent) => {
    drag.current = { x: e.clientX, y: e.clientY, ox: view.ox, oy: view.oy };
  };
  const onMove = (e: React.MouseEvent) => {
    const r = cvRef.current!.getBoundingClientRect();
    const sx = e.clientX - r.left, sy = e.clientY - r.top;
    if (drag.current) {
      setView((v) => ({ ...v, ox: drag.current!.ox + e.clientX - drag.current!.x, oy: drag.current!.oy + e.clientY - drag.current!.y }));
    }
    const w = toWorld(sx, sy);
    setMouse(w);
    if (model && !drag.current) {
      let best: number | null = null, bd = 12 / view.k;
      for (let i = 0; i < model.segs.length; i++) {
        const d = distToSeg(w, model.pts[i], model.pts[i + 1]);
        if (d < bd) { bd = d; best = i; }
      }
      onHoverSide(best);
    }
  };
  const end = () => (drag.current = null);

  const sideInfo = model && hoverSide != null ? model.segs[hoverSide] : null;
  const zoomPct = Math.round((view.k / fitK) * 100);

  return (
    <div ref={wrapRef} className="relative h-full w-full overflow-hidden bg-[#0a111a]">
      <canvas
        ref={cvRef}
        style={{ width: size.w, height: size.h, cursor: drag.current ? "grabbing" : hoverSide != null ? "pointer" : "crosshair" }}
        className="block"
        onMouseDown={onDown}
        onMouseMove={onMove}
        onMouseUp={end}
        onMouseLeave={() => { end(); setMouse(null); onHoverSide(null); }}
        onDoubleClick={fit}
      />

      {/* Инфо-чип масштаба чертежа */}
      <div className="pointer-events-none absolute left-4 top-4 flex items-center gap-2 rounded-lg border border-slate-700/60 bg-slate-900/80 px-3 py-1.5 text-[11px] text-slate-300 backdrop-blur">
        <span className="font-mono text-slate-400">{scaleText}</span>
      </div>

      {/* Зум-контролы */}
      <div className="absolute right-4 top-28 flex flex-col overflow-hidden rounded-lg border border-slate-700/60 bg-slate-900/85 backdrop-blur">
        <button title="Приблизить" onClick={() => zoomAt(size.w / 2, size.h / 2, 1.3)} className="grid h-8 w-8 place-items-center text-slate-300 hover:bg-slate-800"><Plus size={15} /></button>
        <button title="Отдалить" onClick={() => zoomAt(size.w / 2, size.h / 2, 1 / 1.3)} className="grid h-8 w-8 place-items-center border-t border-slate-700/60 text-slate-300 hover:bg-slate-800"><Minus size={15} /></button>
        <button title="Вписать (двойной клик)" onClick={fit} className="grid h-8 w-8 place-items-center border-t border-slate-700/60 text-slate-300 hover:bg-slate-800"><Maximize2 size={14} /></button>
      </div>

      {/* HUD */}
      <div className="pointer-events-none absolute bottom-4 right-4 flex min-w-[220px] flex-col gap-1 rounded-lg border border-slate-700/60 bg-slate-900/85 px-3 py-2 font-mono text-[11px] text-slate-300 backdrop-blur">
        <div className="flex items-center justify-between gap-4">
          <span className="flex items-center gap-1.5 text-slate-500"><Crosshair size={12} /> XY</span>
          <span>{mouse ? `${mouse.x >= 0 ? "+" : ""}${mouse.x.toFixed(2)}',  ${mouse.y >= 0 ? "+" : ""}${mouse.y.toFixed(2)}'` : "—"}</span>
        </div>
        <div className="flex items-center justify-between gap-4">
          <span className="text-slate-500">Сторона</span>
          <span className={sideInfo ? "text-yellow-300" : "text-slate-600"}>
            {sideInfo && hoverSide != null ? `#${hoverSide + 1} · ${fmtBearing(sideInfo)} · ${fmtLen(sideInfo.len)}` : "наведите на линию"}
          </span>
        </div>
        <div className="flex items-center justify-between gap-4 text-slate-500">
          <span>Зум</span><span>{zoomPct}%</span>
        </div>
      </div>

      <div className="pointer-events-none absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full border border-slate-800 bg-slate-900/70 px-3 py-1 text-[10px] text-slate-500">
        Колесо — зум · ЛКМ — панорама · двойной клик — вписать
      </div>

      {!model && (
        <div className="absolute inset-0 grid place-items-center">
          <div className="max-w-xs text-center">
            <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl border border-slate-700 bg-slate-900 text-slate-500">
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M4 18 L9 5 L20 8 L17 19 Z" /><circle cx="4" cy="18" r="1.5" /></svg>
            </div>
            <p className="text-sm font-medium text-slate-300">Схема появится здесь</p>
            <p className="mt-1 text-xs leading-relaxed text-slate-500">Вставьте Legal Description слева и нажмите «Разобрать» <kbd className="rounded bg-slate-800 px-1 text-slate-400">Ctrl+Enter</kbd></p>
          </div>
        </div>
      )}
    </div>
  );
}
