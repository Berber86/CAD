import { useState, type ReactNode } from "react";
import { AlertTriangle, FileText, Loader2, PenLine, ScanSearch, Swords, RefreshCw, CheckCircle2, X } from "lucide-react";
import { Badge, Button, Kbd } from "./ui";
import type { Check } from "../lib/geo";
import type { PassResult } from "../lib/types";
import { cn } from "../utils/cn";

export function Modal({ children, onClose, width = 520 }: { children: ReactNode; onClose?: () => void; width?: number }) {
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" onClick={onClose} />
      <div style={{ width }} className="relative max-w-full overflow-hidden rounded-2xl border border-slate-700 bg-[#0f1926] shadow-2xl">{children}</div>
    </div>
  );
}

export function ShortcutsModal({ onClose }: { onClose: () => void }) {
  const rows: [string[], string][] = [
    [["Ctrl", "Enter"], "Разобрать и проверить"],
    [["F5"], "Начертить участок в AutoCAD"],
    [["Ctrl", "O"], "Загрузить PDF"],
    [["Ctrl", "I"], "Загрузить фото"],
    [["Ctrl", "S"], "Сохранить настройки"],
    [["Esc"], "Закрыть окно"],
    [["Колесо"], "Зум схемы"],
    [["2× клик"], "Вписать схему в окно"],
  ];
  return (
    <Modal onClose={onClose} width={420}>
      <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4">
        <h3 className="text-base font-semibold text-white">Горячие клавиши</h3>
        <button onClick={onClose} className="text-slate-500 hover:text-white"><X size={18} /></button>
      </div>
      <div className="divide-y divide-slate-800/70 px-5 py-1">
        {rows.map(([k, d]) => (
          <div key={d} className="flex items-center justify-between py-2.5 text-[13px]">
            <span className="text-slate-300">{d}</span>
            <span className="flex gap-1">{k.map((x) => <Kbd key={x}>{x}</Kbd>)}</span>
          </div>
        ))}
      </div>
    </Modal>
  );
}

/** Диалог «Спрашивать при сомнении» */
export function DoubtDialog({
  checks, onClose, onKeep, onApply, onFocus,
}: {
  checks: Check[];
  onClose: () => void;
  onKeep: () => void;
  onApply: (c: Check) => void;
  onFocus: () => Promise<string>;
}) {
  const [busy, setBusy] = useState(false);
  const [answer, setAnswer] = useState<string | null>(null);
  const fixable = checks.find((c) => c.fix);
  return (
    <Modal onClose={onClose} width={560}>
      <div className="flex gap-3 border-b border-slate-800 bg-amber-500/5 px-5 py-4">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-amber-500/15 text-amber-400"><AlertTriangle size={18} /></span>
        <div>
          <h3 className="text-base font-semibold text-white">Есть сомнения перед отрисовкой</h3>
          <p className="mt-0.5 text-xs text-slate-400">Программа ничего не меняет сама — решение за вами.</p>
        </div>
      </div>
      <div className="max-h-56 space-y-2 overflow-y-auto px-5 py-4">
        {checks.map((c) => (
          <div key={c.id} className="rounded-lg border border-amber-500/20 bg-slate-900/60 p-3">
            <div className="text-[13px] font-medium text-slate-100">{c.title}</div>
            <div className="mt-0.5 text-xs leading-relaxed text-slate-400">{c.detail}</div>
          </div>
        ))}
        {answer && (
          <div className="flex gap-2 rounded-lg border border-blue-500/30 bg-blue-500/10 p-3 text-xs leading-relaxed text-blue-100">
            <CheckCircle2 size={15} className="mt-0.5 shrink-0 text-blue-300" /> {answer}
          </div>
        )}
      </div>
      <div className="grid gap-2 border-t border-slate-800 bg-[#0b1420] p-4">
        <Button variant="secondary" size="lg" className="justify-start" disabled={busy} onClick={async () => { setBusy(true); setAnswer(await onFocus()); setBusy(false); }}
          icon={busy ? <Loader2 size={16} className="animate-spin" /> : <ScanSearch size={16} />}>
          <span className="text-left"><span className="block text-[13px]">Ещё раунд LLM с фокусом на зону внимания</span><span className="block text-[11px] font-normal text-slate-500">без повторного рендера PDF/фото</span></span>
        </Button>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="secondary" size="md" icon={<FileText size={15} />} onClick={onKeep}>Оставить как в документе</Button>
          <Button variant="amber" size="md" disabled={!fixable} icon={<PenLine size={15} />} onClick={() => fixable && onApply(fixable)}>Применить исправление</Button>
        </div>
        <button onClick={onClose} className="py-1 text-xs text-slate-500 hover:text-slate-300">Отмена — не чертить</button>
      </div>
    </Modal>
  );
}

/** Панель конфликта проходов */
export function ConflictBanner({
  passes, busy, onPick, onRetry,
}: {
  passes: PassResult[];
  busy: boolean;
  onPick: (slot: number) => void;
  onRetry: () => void;
}) {
  const best = Math.min(...passes.map((p) => p.closure));
  return (
    <div className="border-b border-amber-500/30 bg-gradient-to-b from-amber-500/10 to-amber-500/[0.03] px-4 py-3">
      <div className="mb-2.5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm font-semibold text-amber-200">
          <Swords size={16} /> Проходы расходятся — выберите правильный
          <Badge tone="amber">{passes.length} прохода</Badge>
        </div>
        <Button size="sm" variant="secondary" disabled={busy} onClick={onRetry} icon={busy ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}>
          Попробуй разобраться ещё раз
        </Button>
      </div>
      <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${passes.length}, minmax(0,1fr))` }}>
        {passes.map((p) => (
          <div key={p.slot} className={cn("rounded-lg border bg-slate-900/70 p-3", p.closure === best ? "border-emerald-500/40" : "border-slate-700")}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-white">{p.label}</span>
              <span className={cn("font-mono text-[11px]", p.closure <= 0.01 ? "text-emerald-300" : "text-amber-300")}>Δ {p.closure.toFixed(3)} ft</span>
            </div>
            <div className="mt-0.5 truncate text-[11px] text-slate-500">{p.model}</div>
            <div className="mt-2 space-y-1">
              {p.diffs.length === 0 && <div className="text-[11px] text-slate-500">как эталон</div>}
              {p.diffs.map((d, i) => (
                <div key={i} className="rounded bg-slate-950/70 px-2 py-1 font-mono text-[11px]">
                  <span className="text-slate-500">#{d.side + 1} {d.field}: </span>
                  <span className="text-amber-200">{d.mine}</span>
                  <span className="text-slate-600"> ≠ {d.other}</span>
                </div>
              ))}
            </div>
            <Button size="sm" variant={p.closure === best ? "success" : "secondary"} className="mt-2.5 w-full" onClick={() => onPick(p.slot)} icon={<CheckCircle2 size={13} />}>
              Прав {p.label.toLowerCase()}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
