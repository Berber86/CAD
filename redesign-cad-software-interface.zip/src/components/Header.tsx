import { Check, Keyboard, Settings, Ruler, Plug, PlugZap } from "lucide-react";
import { Badge, Segmented } from "./ui";
import { cn } from "../utils/cn";

export type StepState = "todo" | "active" | "done";

type Props = {
  steps: { label: string; state: StepState }[];
  scale: 10 | 16 | 20 | 30;
  onScale: (s: 10 | 16 | 20 | 30) => void;
  acad: boolean;
  onToggleAcad: () => void;
  onSettings: () => void;
  onKeys: () => void;
  keysReady: number;
};

export default function Header(p: Props) {
  return (
    <header className="flex h-14 shrink-0 items-center gap-4 border-b border-slate-800 bg-[#0f1926] px-4">
      {/* Логотип */}
      <div className="flex items-center gap-3">
        <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 shadow-lg shadow-blue-900/40">
          <Ruler size={17} className="text-white" />
        </div>
        <div className="leading-tight">
          <div className="text-sm font-semibold text-white">Title Survey AI</div>
          <div className="text-[10px] text-slate-500">Legal Description → AutoCAD</div>
        </div>
        <Badge tone="green" className="ml-1">v1.0 · STUDIO</Badge>
      </div>

      {/* Степпер */}
      <nav className="mx-auto hidden items-center gap-1 lg:flex">
        {p.steps.map((s, i) => (
          <div key={s.label} className="flex items-center gap-1">
            <div className={cn("flex items-center gap-2 rounded-full px-3 py-1 text-xs font-medium transition",
              s.state === "active" && "bg-blue-500/15 text-blue-200 ring-1 ring-blue-500/40",
              s.state === "done" && "text-emerald-300",
              s.state === "todo" && "text-slate-500")}>
              <span className={cn("grid h-4 w-4 place-items-center rounded-full text-[10px] font-bold",
                s.state === "done" ? "bg-emerald-500 text-slate-950" : s.state === "active" ? "bg-blue-500 text-white" : "bg-slate-800 text-slate-500")}>
                {s.state === "done" ? <Check size={10} strokeWidth={3} /> : i + 1}
              </span>
              {s.label}
            </div>
            {i < p.steps.length - 1 && <span className="h-px w-5 bg-slate-700" />}
          </div>
        ))}
      </nav>

      {/* Справа */}
      <div className="ml-auto flex items-center gap-2 lg:ml-0">
        <div className="hidden items-center gap-2 xl:flex">
          <span className="text-[11px] text-slate-500">Масштаб</span>
          <Segmented
            size="sm"
            value={p.scale}
            onChange={p.onScale}
            options={[10, 16, 20, 30].map((v) => ({ value: v as 10 | 16 | 20 | 30, label: `1"=${v}'` }))}
          />
        </div>
        <button
          onClick={p.onToggleAcad}
          title="Клик — переключить демо-состояние подключения"
          className={cn("flex h-8 items-center gap-2 rounded-lg border px-2.5 text-xs transition",
            p.acad ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/15" : "border-red-500/30 bg-red-500/10 text-red-300 hover:bg-red-500/15")}
        >
          {p.acad ? <PlugZap size={14} /> : <Plug size={14} />}
          <span className="hidden md:inline">{p.acad ? "AutoCAD · Survey.dwg" : "AutoCAD не найден"}</span>
          <span className={cn("h-1.5 w-1.5 rounded-full", p.acad ? "animate-pulse bg-emerald-400" : "bg-red-400")} />
        </button>
        <button onClick={p.onKeys} title="Горячие клавиши" className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white"><Keyboard size={16} /></button>
        <button onClick={p.onSettings} className="flex h-8 items-center gap-2 rounded-lg border border-slate-700 bg-slate-800/70 px-2.5 text-xs text-slate-200 hover:bg-slate-700">
          <Settings size={14} /> Настройки
          <span className={cn("rounded px-1 text-[10px] font-semibold", p.keysReady ? "bg-emerald-500/20 text-emerald-300" : "bg-amber-500/20 text-amber-300")}>
            {p.keysReady ? `🔑 ${p.keysReady}` : "нет ключей"}
          </span>
        </button>
      </div>
    </header>
  );
}
