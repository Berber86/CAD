import {
  AlertTriangle, CheckCircle2, Copy, Eraser, Info, Plus, Ruler, ShieldCheck, ShieldAlert, XCircle, Wand2, FileCheck2, ScanSearch,
} from "lucide-react";
import { fmtBearing, fmtDMS, fmtLen, type Check, type Model, type Neighbor } from "../lib/geo";
import type { LogEntry } from "../lib/types";
import { Badge, Button, SectionTitle, Tabs } from "./ui";
import { cn } from "../utils/cn";

export type ResultTab = "sheet" | "checks" | "neighbors" | "log";

type Props = {
  tab: ResultTab;
  setTab: (t: ResultTab) => void;
  model: Model | null;
  checks: Check[];
  neighbors: Neighbor[];
  hoverSide: number | null;
  onHoverSide: (i: number | null) => void;
  log: LogEntry[];
  tokens: number;
  onCopy: () => void;
  onApplyFix: (c: Check) => void;
  onAddNeighbor: () => void;
  onClearNeighbors: () => void;
  onCopyAct: () => void;
  textHeight: number;
  scale: number;
  onClearLog: () => void;
  onRecheck: () => void;
};

function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: "ok" | "warn" | "err" }) {
  const c = tone === "ok" ? "text-emerald-300" : tone === "warn" ? "text-amber-300" : tone === "err" ? "text-red-300" : "text-white";
  return (
    <div className="rounded-lg border border-slate-800 bg-slate-900/50 px-3 py-2.5">
      <div className="text-[11px] text-slate-500">{label}</div>
      <div className={cn("mt-0.5 font-mono text-[17px] font-semibold leading-tight", c)}>{value}</div>
      {sub && <div className="mt-0.5 text-[11px] text-slate-500">{sub}</div>}
    </div>
  );
}

const LEVEL_ICON = {
  ok: <CheckCircle2 size={16} className="shrink-0 text-emerald-400" />,
  warn: <AlertTriangle size={16} className="shrink-0 text-amber-400" />,
  err: <XCircle size={16} className="shrink-0 text-red-400" />,
};

export default function ResultPanel(p: Props) {
  const { model } = p;
  const bad = p.checks.filter((c) => c.level !== "ok").length;

  const closureTone = !model ? undefined : model.closure <= 0.01 ? "ok" : model.closure < 0.5 ? "warn" : "err";

  return (
    <aside className="flex min-h-0 flex-col border-l border-slate-800 bg-[#0d1622]">
      <div className="flex items-center justify-between px-4 pb-1 pt-4">
        <div className="flex items-center gap-2.5">
          <span className="grid h-6 w-6 place-items-center rounded-md bg-blue-600/20 text-[12px] font-bold text-blue-300">2</span>
          <h2 className="text-sm font-semibold text-white">Результат</h2>
        </div>
        <Button size="sm" variant="ghost" disabled={!model} onClick={p.onCopy} icon={<Copy size={13} />}>Копировать</Button>
      </div>

      <Tabs
        value={p.tab}
        onChange={p.setTab}
        tabs={[
          { value: "sheet", label: "Ведомость" },
          {
            value: "checks",
            label: "Проверки",
            badge: model ? (
              bad ? <span className="grid h-4 min-w-4 place-items-center rounded-full bg-amber-500 px-1 text-[10px] font-bold text-slate-950">{bad}</span> : <ShieldCheck size={13} className="text-emerald-400" />
            ) : undefined,
          },
          { value: "neighbors", label: "Соседи", badge: p.neighbors.length ? <span className="rounded-full bg-teal-500/20 px-1.5 text-[10px] font-bold text-teal-300">{p.neighbors.length}</span> : undefined },
          { value: "log", label: "Журнал" },
        ]}
      />

      <div className="min-h-0 flex-1 overflow-y-auto p-4">
        {/* ───── Ведомость ───── */}
        {p.tab === "sheet" &&
          (model ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <Stat label="Невязка (Closure)" value={`${model.closure.toFixed(3)} ft`} tone={closureTone} sub={model.closure <= 0.01 ? "контур замкнут" : "есть открытый гэп"} />
                <Stat label="Площадь" value={`${Math.round(model.area).toLocaleString("en-US")} sq ft`} sub={`${(model.area / 43560).toFixed(4)} acres`} />
                <Stat label="Периметр" value={`${model.perimeter.toFixed(2)} ft`} sub={`${model.segs.length} сторон`} />
                <Stat label="Высота текста" value={p.textHeight.toFixed(2)} sub={`масштаб 1"=${p.scale}'`} />
              </div>

              <div>
                <SectionTitle>Привязка</SectionTitle>
                <div className="space-y-1.5 rounded-lg border border-slate-800 bg-slate-900/50 p-3 text-xs">
                  <Row k="Фасад" v={model.mainStreet} />
                  <Row k="Пересечение" v={model.crossStreet} />
                  <Row k="Угол → POB" v={`${model.tie.toFixed(2)} ft`} mono />
                  <Row k="POB (X, Y)" v={`${model.pob.x.toFixed(2)}, ${model.pob.y.toFixed(2)}`} mono />
                </div>
              </div>

              <div>
                <SectionTitle right={<span className="text-[11px] text-slate-600">наведите — подсветка на схеме</span>}>Стороны</SectionTitle>
                <div className="overflow-hidden rounded-lg border border-slate-800">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="bg-slate-900/80 text-left text-[11px] text-slate-500">
                        <th className="w-8 px-2 py-1.5 font-medium">№</th>
                        <th className="px-2 py-1.5 font-medium">Румб</th>
                        <th className="px-2 py-1.5 text-right font-medium">Длина</th>
                        <th className="px-2 py-1.5 text-right font-medium">Угол</th>
                      </tr>
                    </thead>
                    <tbody className="font-mono">
                      {model.segs.map((s, i) => {
                        const sus = p.checks.some((c) => c.level !== "ok" && c.sides.includes(i));
                        return (
                          <tr
                            key={i}
                            onMouseEnter={() => p.onHoverSide(i)}
                            onMouseLeave={() => p.onHoverSide(null)}
                            className={cn("cursor-default border-t border-slate-800/80 transition", p.hoverSide === i ? "bg-yellow-400/10" : "hover:bg-slate-800/50")}
                          >
                            <td className="px-2 py-1.5">
                              <span className={cn("grid h-5 w-5 place-items-center rounded-full text-[10px] font-bold", sus ? "bg-amber-400 text-slate-950" : "bg-slate-800 text-slate-400")}>{i + 1}</span>
                            </td>
                            <td className="px-2 py-1.5 text-emerald-300">{fmtBearing(s)}</td>
                            <td className="px-2 py-1.5 text-right text-slate-200">{fmtLen(s.len)}</td>
                            <td className="px-2 py-1.5 text-right text-slate-400">{fmtDMS(model.angles[i])}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <Empty icon={<Ruler size={22} />} title="Ведомость пуста" text="После разбора здесь появятся стороны, площадь, периметр и привязка к перекрёстку." />
          ))}

        {/* ───── Проверки ───── */}
        {p.tab === "checks" &&
          (model ? (
            <div className="space-y-2.5">
              <div className={cn("flex items-center gap-3 rounded-lg border px-3 py-2.5", bad ? "border-amber-500/30 bg-amber-500/5" : "border-emerald-500/30 bg-emerald-500/5")}>
                {bad ? <ShieldAlert className="text-amber-400" size={20} /> : <ShieldCheck className="text-emerald-400" size={20} />}
                <div className="text-xs">
                  <div className="text-sm font-semibold text-white">{bad ? `Подозрительно: ${bad}` : "Всё в порядке"}</div>
                  <div className="text-slate-400">{bad ? "Проверьте отмеченные стороны по документу" : `${p.checks.length} проверок пройдено`}</div>
                </div>
              </div>
              {[...p.checks].sort((a, b) => (a.level === "ok" ? 1 : 0) - (b.level === "ok" ? 1 : 0)).map((c) => (
                <div
                  key={c.id}
                  onMouseEnter={() => c.sides[0] != null && p.onHoverSide(c.sides[0])}
                  onMouseLeave={() => p.onHoverSide(null)}
                  className={cn("rounded-lg border p-3", c.level === "ok" ? "border-slate-800 bg-slate-900/40" : c.level === "warn" ? "border-amber-500/30 bg-amber-500/5" : "border-red-500/30 bg-red-500/5")}
                >
                  <div className="flex gap-2.5">
                    {LEVEL_ICON[c.level]}
                    <div className="min-w-0 flex-1">
                      <div className="text-[13px] font-medium text-slate-100">{c.title}</div>
                      <div className="mt-0.5 text-xs leading-relaxed text-slate-400">{c.detail}</div>
                      {c.fix && (
                        <div className="mt-2.5 flex flex-wrap gap-1.5">
                          <Button size="sm" variant="amber" icon={<Wand2 size={13} />} onClick={() => p.onApplyFix(c)}>
                            Применить {c.fix.from.toFixed(2)} → {c.fix.to.toFixed(2)}
                          </Button>
                          <Button size="sm" variant="secondary" icon={<ScanSearch size={13} />} onClick={p.onRecheck}>Перепроверить ИИ</Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <Empty icon={<ShieldCheck size={22} />} title="Проверок пока нет" text="Замыкание, сумма углов, теоремы для четырёхугольников, самопересечения, потерянные точки." />
          ))}

        {/* ───── Соседи ───── */}
        {p.tab === "neighbors" && (
          <div className="space-y-3">
            <div className="flex gap-2">
              <Button variant="teal" className="flex-1" disabled={!model} onClick={p.onAddNeighbor} icon={<Plus size={15} />}>Добавить соседа</Button>
              <Button variant="secondary" disabled={!p.neighbors.length} onClick={p.onClearNeighbors} title="Убрать всех"><Eraser size={14} /></Button>
            </div>
            {p.neighbors.length ? (
              <>
                {p.neighbors.map((n) => (
                  <div key={n.id} className={cn("rounded-lg border p-3", n.level === "warn" ? "border-amber-500/30 bg-amber-500/5" : "border-teal-500/25 bg-teal-500/5")}>
                    <div className="flex items-center justify-between">
                      <span className="text-[13px] font-semibold text-white">{n.name}</span>
                      <Badge tone={n.level === "warn" ? "amber" : "green"}>{n.title}</Badge>
                    </div>
                    <p className="mt-1.5 text-xs leading-relaxed text-slate-400">{n.detail}</p>
                  </div>
                ))}
                <Button variant="secondary" className="w-full" onClick={p.onCopyAct} icon={<FileCheck2 size={14} />}>Скопировать акт сверки</Button>
              </>
            ) : (
              <Empty icon={<Info size={22} />} title="Соседей нет" text="Добавьте соседний участок — он встанет стенка к стенке и сразу проверится на щели, клинья и наложения." />
            )}
          </div>
        )}

        {/* ───── Журнал ───── */}
        {p.tab === "log" && (
          <div>
            <div className="mb-3 flex items-center justify-between text-xs text-slate-500">
              <span>Токены за сессию: <span className="font-mono text-slate-300">{p.tokens.toLocaleString("ru-RU")}</span></span>
              <button onClick={p.onClearLog} className="hover:text-slate-300">Очистить</button>
            </div>
            <div className="space-y-1 font-mono text-[11.5px] leading-relaxed">
              {p.log.length === 0 && <div className="text-slate-600">Журнал пуст</div>}
              {[...p.log].reverse().map((l, i) => (
                <div key={i} className="flex gap-2">
                  <span className="shrink-0 text-slate-600">{l.t}</span>
                  <span className={l.level === "ok" ? "text-emerald-300" : l.level === "warn" ? "text-amber-300" : l.level === "err" ? "text-red-300" : "text-slate-400"}>{l.msg}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}

function Row({ k, v, mono }: { k: string; v: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-slate-500">{k}</span>
      <span className={cn("truncate text-slate-200", mono && "font-mono")}>{v}</span>
    </div>
  );
}

function Empty({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="grid place-items-center px-4 py-14 text-center">
      <div className="mb-3 grid h-12 w-12 place-items-center rounded-xl border border-slate-800 bg-slate-900 text-slate-500">{icon}</div>
      <div className="text-sm font-medium text-slate-300">{title}</div>
      <p className="mt-1 max-w-[260px] text-xs leading-relaxed text-slate-500">{text}</p>
    </div>
  );
}
