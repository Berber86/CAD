import { useState } from "react";
import { Eye, EyeOff, KeyRound, Lock, Save, ShieldCheck, X } from "lucide-react";
import { Badge, Button, Segmented, SectionTitle, Toggle } from "./ui";
import { MODELS, type Provider, type Settings, type Slot } from "../lib/types";

const PROVIDERS = Object.keys(MODELS) as Provider[];

function SlotRow({ title, hint, slot, onChange }: { title: string; hint?: string; slot: Slot; onChange: (s: Slot) => void }) {
  return (
    <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[13px] font-medium text-slate-100">{title}</span>
        {hint && <span className="text-[11px] text-slate-500">{hint}</span>}
      </div>
      <div className="grid grid-cols-[130px_1fr] gap-2">
        <select
          value={slot.provider}
          onChange={(e) => onChange({ provider: e.target.value as Provider, model: MODELS[e.target.value as Provider][0] })}
          className="h-9 rounded-lg border border-slate-700 bg-slate-950 px-2 text-xs text-slate-200 outline-none focus:border-blue-500"
        >
          {PROVIDERS.map((p) => <option key={p}>{p}</option>)}
        </select>
        <input
          list={`models-${slot.provider}`}
          value={slot.model}
          onChange={(e) => onChange({ ...slot, model: e.target.value })}
          className="h-9 min-w-0 rounded-lg border border-slate-700 bg-slate-950 px-2.5 font-mono text-xs text-slate-200 outline-none focus:border-blue-500"
        />
        <datalist id={`models-${slot.provider}`}>{MODELS[slot.provider].map((m) => <option key={m} value={m} />)}</datalist>
      </div>
    </div>
  );
}

export default function SettingsDrawer({ open, onClose, s, setS, onSave }: { open: boolean; onClose: () => void; s: Settings; setS: (s: Settings) => void; onSave: () => void }) {
  const [show, setShow] = useState<Record<string, boolean>>({});
  if (!open) return null;
  const setSlot = (i: number, v: Slot) => {
    const slots = [...s.slots] as Settings["slots"];
    slots[i] = v;
    setS({ ...s, slots });
  };
  const ready = PROVIDERS.filter((p) => s.keys[p].trim()).length;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px]" onClick={onClose} />
      <div className="relative flex h-full w-[460px] max-w-full flex-col border-l border-slate-700 bg-[#0d1622] shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4">
          <div>
            <h2 className="text-base font-semibold text-white">Настройки</h2>
            <p className="text-xs text-slate-500">ИИ-движок, режим сверки и API-ключи</p>
          </div>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white"><X size={18} /></button>
        </div>

        <div className="flex-1 space-y-6 overflow-y-auto p-5">
          <section>
            <SectionTitle>Режим сверки LLM</SectionTitle>
            <Segmented
              className="w-full"
              value={s.passes}
              onChange={(v) => setS({ ...s, passes: v as 1 | 2 | 3 })}
              options={[{ value: 1, label: "1 проход" }, { value: 2, label: "2 прохода" }, { value: 3, label: "3 прохода" }]}
            />
            <p className="mt-2 text-xs leading-relaxed text-slate-500">
              {s.passes === 1 ? "Один запрос — самый быстрый и дешёвый." : "Независимые запросы идут параллельно. Расхождение откроет панель выбора, совпадение — построит участок сразу."}
            </p>
            <div className="mt-3 space-y-2">
              <SlotRow title="Проход #1" slot={s.slots[0]} onChange={(v) => setSlot(0, v)} />
              {s.passes >= 2 && <SlotRow title="Проход #2" hint="независимая сверка" slot={s.slots[1]} onChange={(v) => setSlot(1, v)} />}
              {s.passes >= 3 && <SlotRow title="Проход #3" hint="арбитражный слот" slot={s.slots[2]} onChange={(v) => setSlot(2, v)} />}
            </div>
          </section>

          <section className="space-y-3 rounded-lg border border-slate-800 bg-slate-900/40 p-4">
            <Toggle checked={s.askOnDoubt} onChange={(v) => setS({ ...s, askOnDoubt: v })} label="Спрашивать при сомнении" hint="Остановиться и предложить выбор, если есть подозрение на опечатку или контур не замкнут." />
            <Toggle checked={s.alwaysOnTop} onChange={(v) => setS({ ...s, alwaysOnTop: v })} label="Поверх всех окон" />
          </section>

          <section>
            <SectionTitle right={<Badge tone={ready ? "green" : "slate"}>готовы: {ready}/3</Badge>}>API-ключи</SectionTitle>
            <div className="space-y-2.5">
              {PROVIDERS.map((p) => (
                <label key={p} className="block">
                  <span className="mb-1 flex items-center gap-1.5 text-xs text-slate-400"><KeyRound size={12} /> {p}</span>
                  <div className="relative">
                    <input
                      type={show[p] ? "text" : "password"}
                      value={s.keys[p]}
                      onChange={(e) => setS({ ...s, keys: { ...s.keys, [p]: e.target.value } })}
                      placeholder="sk-…"
                      className="h-9 w-full rounded-lg border border-slate-700 bg-slate-950 pl-3 pr-9 font-mono text-xs text-slate-200 outline-none placeholder:text-slate-600 focus:border-blue-500"
                    />
                    <button type="button" onClick={() => setShow({ ...show, [p]: !show[p] })} className="absolute right-1.5 top-1.5 grid h-6 w-6 place-items-center rounded text-slate-500 hover:text-slate-200">
                      {show[p] ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </label>
              ))}
              <label className="block pt-1">
                <span className="mb-1 flex items-center gap-1.5 text-xs text-slate-400"><Lock size={12} /> PIN для шифрования <span className="text-slate-600">(только в RAM)</span></span>
                <input type="password" value={s.pin} onChange={(e) => setS({ ...s, pin: e.target.value })} className="h-9 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 font-mono text-xs text-slate-200 outline-none focus:border-blue-500" />
              </label>
              <p className="flex items-start gap-2 text-xs leading-relaxed text-slate-500"><ShieldCheck size={14} className="mt-0.5 shrink-0 text-emerald-500" /> На диск попадают только зашифрованные токены tsai1:… (DPAPI + PIN).</p>
            </div>
          </section>
        </div>

        <div className="flex items-center justify-between gap-2 border-t border-slate-800 bg-[#0b1420] px-5 py-3">
          <Button variant="secondary" icon={<ShieldCheck size={14} />} onClick={onSave}>Защитить в .env</Button>
          <Button variant="primary" icon={<Save size={14} />} onClick={() => { onSave(); onClose(); }}>Сохранить <span className="ml-1 text-[10px] opacity-70">Ctrl+S</span></Button>
        </div>
      </div>
    </div>
  );
}
