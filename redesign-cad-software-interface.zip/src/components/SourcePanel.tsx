import { useRef, useState } from "react";
import {
  Camera, ChevronLeft, ChevronRight, ClipboardList, FileText, FlipVertical2, Loader2, RotateCcw, RotateCw,
  Settings2, Sparkles, Trash2, Type, UploadCloud, Wand2, Zap, Check,
} from "lucide-react";
import { Badge, Button, Kbd, Segmented, SectionTitle, Toggle } from "./ui";
import type { Photo, Settings } from "../lib/types";

export type SourceMode = "text" | "pdf" | "photo";

type Props = {
  mode: SourceMode;
  setMode: (m: SourceMode) => void;
  text: string;
  setText: (t: string) => void;
  onSample: (kind: "ok" | "typo") => void;
  pdfName: string | null;
  pages: string;
  setPages: (s: string) => void;
  onPickPdf: () => void;
  onPickPhotos: () => void;
  photos: Photo[];
  photoIdx: number;
  setPhotoIdx: (n: number) => void;
  rotatePhoto: (d: number) => void;
  removePhoto: () => void;
  settings: Settings;
  setSettings: (s: Settings) => void;
  openSettings: () => void;
  running: boolean;
  progress: { label: string; state: "wait" | "run" | "done" }[];
  onAnalyze: (ai: boolean) => void;
  stale: boolean;
};

export default function SourcePanel(p: Props) {
  const [sampleOpen, setSampleOpen] = useState(false);
  const photo = p.photos[p.photoIdx];
  const taRef = useRef<HTMLTextAreaElement>(null);
  const s = p.settings;
  const slot = s.slots[0];

  return (
    <aside className="flex min-h-0 flex-col border-r border-slate-800 bg-[#0d1622]">
      {/* Заголовок */}
      <div className="flex items-center justify-between px-4 pb-3 pt-4">
        <div className="flex items-center gap-2.5">
          <span className="grid h-6 w-6 place-items-center rounded-md bg-blue-600/20 text-[12px] font-bold text-blue-300">1</span>
          <h2 className="text-sm font-semibold text-white">Исходные данные</h2>
        </div>
        {p.stale && <Badge tone="amber">изменён после разбора</Badge>}
      </div>

      <div className="px-4">
        <Segmented
          className="w-full"
          value={p.mode}
          onChange={p.setMode}
          options={[
            { value: "text", label: <><Type size={13} /> Текст</> },
            { value: "pdf", label: <><FileText size={13} /> PDF</> },
            { value: "photo", label: <><Camera size={13} /> Фото</> },
          ]}
        />
      </div>

      {/* Источник */}
      <div className="mt-3 min-h-0 flex-1 overflow-y-auto px-4 pb-3">
        {p.mode === "text" && (
          <div className="flex h-full min-h-[220px] flex-col">
            <div className="mb-2 flex items-center justify-between">
              <SectionTitle>Legal Description</SectionTitle>
              <div className="relative -mt-2 flex items-center gap-1">
                <button onClick={() => setSampleOpen((v) => !v)} className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-slate-400 hover:bg-slate-800 hover:text-white">
                  <ClipboardList size={13} /> Пример
                </button>
                <button onClick={() => p.setText("")} className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-slate-400 hover:bg-slate-800 hover:text-white">
                  <Trash2 size={13} /> Очистить
                </button>
                {sampleOpen && (
                  <div className="absolute right-0 top-8 z-20 w-56 overflow-hidden rounded-lg border border-slate-700 bg-slate-900 shadow-xl">
                    <button className="block w-full px-3 py-2 text-left text-xs text-slate-200 hover:bg-slate-800" onClick={() => { p.onSample("ok"); setSampleOpen(false); }}>
                      Чистый участок<span className="block text-[11px] text-slate-500">4 стороны, невязка 0</span>
                    </button>
                    <button className="block w-full border-t border-slate-800 px-3 py-2 text-left text-xs text-slate-200 hover:bg-slate-800" onClick={() => { p.onSample("typo"); setSampleOpen(false); }}>
                      С опечаткой 120 → 126<span className="block text-[11px] text-slate-500">покажет диалог сомнения</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
            <textarea
              ref={taRef}
              value={p.text}
              onChange={(e) => p.setText(e.target.value)}
              spellCheck={false}
              placeholder={"Вставьте описание границ:\n\nTHENCE N 75°20'20\" E, a distance of 120.00 feet…"}
              className="min-h-[200px] flex-1 resize-none rounded-lg border border-slate-800 bg-[#080e16] p-3 font-mono text-[12px] leading-relaxed text-slate-300 outline-none placeholder:text-slate-600 focus:border-blue-500/60 focus:ring-2 focus:ring-blue-500/15"
            />
            <div className="mt-1.5 text-right text-[11px] text-slate-600">{p.text.length} симв.</div>
          </div>
        )}

        {p.mode === "pdf" && (
          <div className="space-y-3">
            <button onClick={p.onPickPdf} className="group flex w-full flex-col items-center gap-2 rounded-xl border border-dashed border-slate-700 bg-slate-900/40 px-4 py-8 text-center transition hover:border-blue-500/60 hover:bg-blue-500/5">
              <UploadCloud className="text-slate-500 transition group-hover:text-blue-400" size={26} />
              <span className="text-sm font-medium text-slate-200">{p.pdfName ?? "Выберите PDF"}</span>
              <span className="text-xs text-slate-500">Текстовый, векторный или скан · <Kbd>Ctrl</Kbd> + <Kbd>O</Kbd></span>
            </button>
            <label className="flex items-center justify-between gap-3 rounded-lg border border-slate-800 bg-slate-900/40 px-3 py-2">
              <span className="text-[13px] text-slate-300">Страницы</span>
              <input value={p.pages} onChange={(e) => p.setPages(e.target.value)} placeholder="1-8 / все" className="w-28 rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-right text-xs text-slate-200 outline-none focus:border-blue-500" />
            </label>
            <p className="text-xs leading-relaxed text-slate-500">Если в PDF есть текст обхода — он читается напрямую. Скан или чертёж без текста автоматически уходит в Vision-модель.</p>
          </div>
        )}

        {p.mode === "photo" && (
          <div className="space-y-3">
            {!photo ? (
              <button onClick={p.onPickPhotos} className="group flex w-full flex-col items-center gap-2 rounded-xl border border-dashed border-slate-700 bg-slate-900/40 px-4 py-8 text-center transition hover:border-blue-500/60 hover:bg-blue-500/5">
                <Camera className="text-slate-500 transition group-hover:text-blue-400" size={26} />
                <span className="text-sm font-medium text-slate-200">Загрузить фото чертежа</span>
                <span className="text-xs text-slate-500">JPG · PNG · TIFF · несколько кадров · <Kbd>Ctrl</Kbd> + <Kbd>I</Kbd></span>
              </button>
            ) : (
              <>
                <div className="relative grid h-44 place-items-center overflow-hidden rounded-xl border border-slate-800 bg-black/40">
                  <img src={photo.url} alt={photo.name} style={{ transform: `rotate(${photo.rot}deg)` }} className="max-h-full max-w-full object-contain transition-transform" />
                  <span className="absolute left-2 top-2 rounded bg-slate-950/80 px-1.5 py-0.5 text-[11px] text-slate-300">Кадр {p.photoIdx + 1}/{p.photos.length} · {((photo.rot % 360) + 360) % 360}°</span>
                </div>
                <div className="flex items-center justify-between gap-1">
                  <div className="flex gap-1">
                    <Button size="sm" variant="secondary" title="Предыдущий" disabled={p.photoIdx === 0} onClick={() => p.setPhotoIdx(p.photoIdx - 1)}><ChevronLeft size={14} /></Button>
                    <Button size="sm" variant="secondary" title="Следующий" disabled={p.photoIdx >= p.photos.length - 1} onClick={() => p.setPhotoIdx(p.photoIdx + 1)}><ChevronRight size={14} /></Button>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="secondary" title="−90°" onClick={() => p.rotatePhoto(-90)}><RotateCcw size={14} /></Button>
                    <Button size="sm" variant="secondary" title="+90°" onClick={() => p.rotatePhoto(90)}><RotateCw size={14} /></Button>
                    <Button size="sm" variant="secondary" title="180°" onClick={() => p.rotatePhoto(180)}><FlipVertical2 size={14} /></Button>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={p.onPickPhotos}>Ещё…</Button>
                    <Button size="sm" variant="ghost" title="Удалить кадр" onClick={p.removePhoto}><Trash2 size={14} /></Button>
                  </div>
                </div>
              </>
            )}
            <div className="space-y-3 rounded-lg border border-slate-800 bg-slate-900/40 p-3">
              <Toggle checked={s.sharpen} onChange={(v) => p.setSettings({ ...s, sharpen: v })} label="Чёткость фото 80-х" hint="Контраст и резкость без искажения цветов" />
              <Toggle
                checked={s.aiRotate}
                onChange={(v) => p.setSettings({ ...s, aiRotate: v })}
                label={<span className="flex items-center gap-2">ИИ-поворот <Badge tone="amber">платно</Badge></span>}
                hint="Один раз на запуск. Ручной поворот бесплатен."
              />
            </div>
          </div>
        )}

        {/* Прогресс разбора */}
        {p.running && (
          <div className="mt-3 space-y-1.5 rounded-lg border border-blue-500/25 bg-blue-500/5 p-3">
            {p.progress.map((r, i) => (
              <div key={i} className="flex items-center gap-2 text-xs">
                {r.state === "done" ? <Check size={14} className="text-emerald-400" /> : r.state === "run" ? <Loader2 size={14} className="animate-spin text-blue-400" /> : <span className="h-3.5 w-3.5 rounded-full border border-slate-600" />}
                <span className={r.state === "wait" ? "text-slate-500" : "text-slate-200"}>{r.label}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ИИ-движок */}
      <div className="border-t border-slate-800 px-4 py-3">
        <div className="mb-2 flex items-center justify-between">
          <SectionTitle>ИИ-движок</SectionTitle>
          <button onClick={p.openSettings} className="-mt-2 flex items-center gap-1 rounded-md px-2 py-1 text-xs text-blue-300 hover:bg-blue-500/10">
            <Settings2 size={13} /> Настроить
          </button>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-2.5">
          <div className="flex items-center gap-2 text-xs">
            <span className="grid h-6 w-6 place-items-center rounded-md bg-violet-500/15 text-violet-300"><Sparkles size={13} /></span>
            <div className="min-w-0 flex-1">
              <div className="truncate font-medium text-slate-200">{slot.model}</div>
              <div className="text-[11px] text-slate-500">{slot.provider}{s.passes > 1 && ` + ещё ${s.passes - 1}`}</div>
            </div>
            {s.askOnDoubt && <Badge tone="blue" className="shrink-0">спрашивать</Badge>}
          </div>
          <div className="mt-2.5 flex items-center gap-2">
            <span className="text-[11px] text-slate-500">Сверка</span>
            <Segmented
              size="sm"
              className="flex-1"
              value={s.passes}
              onChange={(v) => p.setSettings({ ...s, passes: v as 1 | 2 | 3 })}
              options={[{ value: 1, label: "1 проход" }, { value: 2, label: "2" }, { value: 3, label: "3" }]}
            />
          </div>
        </div>
      </div>

      {/* Главное действие */}
      <div className="space-y-2 border-t border-slate-800 bg-[#0b1420] p-4">
        <Button
          variant="primary"
          size="lg"
          className="w-full"
          disabled={p.running || (p.mode === "text" && !p.text.trim())}
          onClick={() => p.onAnalyze(true)}
          icon={p.running ? <Loader2 size={16} className="animate-spin" /> : <Wand2 size={16} />}
        >
          {p.running ? "Идёт разбор…" : "Разобрать и проверить"}
          {!p.running && <span className="ml-1 hidden gap-1 sm:inline-flex"><Kbd>Ctrl</Kbd><Kbd>↵</Kbd></span>}
        </Button>
        <button
          disabled={p.running || p.mode !== "text" || !p.text.trim()}
          onClick={() => p.onAnalyze(false)}
          className="flex w-full items-center justify-center gap-1.5 rounded-md py-1 text-xs text-slate-500 transition hover:text-slate-300 disabled:opacity-40"
        >
          <Zap size={12} /> Быстрый разбор без ИИ (regex, бесплатно)
        </button>
      </div>
    </aside>
  );
}

