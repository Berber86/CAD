import { useMemo } from "react";
import type { Model } from "../lib/geo";
import type { Photo } from "../lib/types";
import { cn } from "../utils/cn";

type Props = {
  text: string;
  model: Model | null;
  photo?: Photo;
  usePhoto: boolean;
  pdfName: string | null;
  hoverSide: number | null;
  onHoverSide: (i: number | null) => void;
  suspect: number[];
};

/** «Исходник»: документ с подсвеченными распознанными сторонами; клик/наведение синхронизируется со схемой. */
export default function SourceView({ text, model, photo, usePhoto, hoverSide, onHoverSide, suspect }: Props) {
  const parts = useMemo(() => {
    if (!model) return [{ t: text, side: -1 }];
    const out: { t: string; side: number }[] = [];
    let pos = 0;
    model.segs.forEach((s, i) => {
      if (s.start < pos || s.end > text.length) return;
      out.push({ t: text.slice(pos, s.start), side: -1 });
      out.push({ t: text.slice(s.start, s.end), side: i });
      pos = s.end;
    });
    out.push({ t: text.slice(pos), side: -1 });
    return out;
  }, [text, model]);

  if (usePhoto && photo) {
    return (
      <div className="grid h-full place-items-center overflow-auto bg-[#080e16] p-6">
        <img src={photo.url} alt={photo.name} style={{ transform: `rotate(${photo.rot}deg)` }} className="max-h-full max-w-full rounded-lg object-contain shadow-2xl" />
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto bg-[#080e16] p-6">
      <div className="mx-auto max-w-2xl rounded-xl border border-slate-800 bg-[#0d1622] p-8 shadow-xl">
        <div className="mb-4 flex items-center justify-between border-b border-slate-800 pb-3 text-[11px] uppercase tracking-wider text-slate-500">
          <span>Legal Description</span>
          {model && <span className="normal-case tracking-normal text-slate-500">найдено сторон: <span className="text-emerald-300">{model.segs.length}</span></span>}
        </div>
        {text.trim() ? (
          <p className="whitespace-pre-wrap font-serif text-[15px] leading-8 text-slate-300">
            {parts.map((p, i) =>
              p.side < 0 ? (
                <span key={i}>{p.t}</span>
              ) : (
                <mark
                  key={i}
                  onMouseEnter={() => onHoverSide(p.side)}
                  onMouseLeave={() => onHoverSide(null)}
                  className={cn(
                    "cursor-pointer rounded px-0.5 transition",
                    hoverSide === p.side ? "bg-yellow-300 text-slate-950" : suspect.includes(p.side) ? "bg-amber-500/25 text-amber-100 underline decoration-amber-400 decoration-wavy" : "bg-emerald-500/15 text-emerald-200 hover:bg-emerald-500/30"
                  )}
                >
                  {p.t}
                  <sup className="ml-0.5 font-sans text-[10px] font-bold opacity-70">{p.side + 1}</sup>
                </mark>
              )
            )}
          </p>
        ) : (
          <p className="text-sm text-slate-600">Текст не загружен</p>
        )}
      </div>
      <p className="mt-3 text-center text-xs text-slate-600">Подсвечено то, что программа прочитала как сторону. Наведите — сторона выделится на схеме.</p>
    </div>
  );
}
