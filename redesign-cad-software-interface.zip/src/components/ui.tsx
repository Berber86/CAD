import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "../utils/cn";

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "teal" | "secondary" | "ghost" | "amber" | "danger" | "success";
  size?: "sm" | "md" | "lg";
  icon?: ReactNode;
};

const V: Record<string, string> = {
  primary: "bg-blue-600 text-white hover:bg-blue-500 shadow-[0_1px_0_rgba(255,255,255,.15)_inset,0_6px_16px_-6px_rgba(37,99,235,.7)]",
  teal: "bg-teal-600 text-white hover:bg-teal-500",
  success: "bg-emerald-600 text-white hover:bg-emerald-500",
  secondary: "bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700/70",
  ghost: "text-slate-300 hover:bg-slate-800/80 hover:text-white",
  amber: "bg-amber-600/90 text-white hover:bg-amber-500",
  danger: "bg-red-500/15 text-red-300 hover:bg-red-500/25 border border-red-500/30",
};
const SZ = { sm: "h-8 px-2.5 text-xs gap-1.5", md: "h-9 px-3.5 text-[13px] gap-2", lg: "h-11 px-5 text-sm gap-2.5" };

export function Button({ variant = "secondary", size = "md", icon, className, children, ...p }: BtnProps) {
  return (
    <button
      {...p}
      className={cn(
        "inline-flex shrink-0 select-none items-center justify-center whitespace-nowrap rounded-lg font-medium outline-none transition focus-visible:ring-2 focus-visible:ring-blue-400/60 disabled:cursor-not-allowed disabled:opacity-40",
        V[variant],
        SZ[size],
        className
      )}
    >
      {icon}
      {children}
    </button>
  );
}

export function Segmented<T extends string | number>({
  value,
  onChange,
  options,
  className,
  size = "md",
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: ReactNode; title?: string }[];
  className?: string;
  size?: "sm" | "md";
}) {
  return (
    <div className={cn("inline-flex rounded-lg border border-slate-700/70 bg-slate-950/60 p-0.5", className)}>
      {options.map((o) => (
        <button
          key={String(o.value)}
          title={o.title}
          onClick={() => onChange(o.value)}
          className={cn(
            "flex flex-1 items-center justify-center gap-1.5 rounded-md font-medium transition",
            size === "sm" ? "h-7 px-2.5 text-xs" : "h-8 px-3 text-[13px]",
            value === o.value ? "bg-slate-700 text-white shadow" : "text-slate-400 hover:text-slate-200"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Toggle({ checked, onChange, label, hint }: { checked: boolean; onChange: (v: boolean) => void; label: ReactNode; hint?: ReactNode }) {
  return (
    <label className="flex cursor-pointer items-start gap-3">
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn("relative mt-0.5 h-5 w-9 shrink-0 rounded-full transition", checked ? "bg-blue-600" : "bg-slate-700")}
      >
        <span className={cn("absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all", checked ? "left-[18px]" : "left-0.5")} />
      </button>
      <span className="min-w-0">
        <span className="block text-[13px] text-slate-200">{label}</span>
        {hint && <span className="mt-0.5 block text-xs leading-snug text-slate-500">{hint}</span>}
      </span>
    </label>
  );
}

export function Badge({ children, tone = "slate", className }: { children: ReactNode; tone?: "slate" | "green" | "amber" | "red" | "blue" | "teal"; className?: string }) {
  const t = {
    slate: "bg-slate-800 text-slate-300 border-slate-700",
    green: "bg-emerald-500/10 text-emerald-300 border-emerald-500/30",
    amber: "bg-amber-500/10 text-amber-300 border-amber-500/30",
    red: "bg-red-500/10 text-red-300 border-red-500/30",
    blue: "bg-blue-500/10 text-blue-300 border-blue-500/30",
    teal: "bg-teal-500/10 text-teal-300 border-teal-500/30",
  }[tone];
  return <span className={cn("inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[11px] font-medium", t, className)}>{children}</span>;
}

export function SectionTitle({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-2 flex items-center justify-between">
      <h3 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">{children}</h3>
      {right}
    </div>
  );
}

export function Kbd({ children }: { children: ReactNode }) {
  return <kbd className="rounded border border-slate-600/80 bg-slate-800 px-1.5 py-px font-mono text-[10px] text-slate-300">{children}</kbd>;
}

export function Tabs<T extends string>({
  value,
  onChange,
  tabs,
}: {
  value: T;
  onChange: (v: T) => void;
  tabs: { value: T; label: ReactNode; badge?: ReactNode }[];
}) {
  return (
    <div className="flex gap-1 border-b border-slate-800 px-2">
      {tabs.map((t) => (
        <button
          key={t.value}
          onClick={() => onChange(t.value)}
          className={cn(
            "relative flex items-center gap-1.5 px-3 py-2.5 text-[13px] font-medium transition",
            value === t.value ? "text-white" : "text-slate-500 hover:text-slate-300"
          )}
        >
          {t.label}
          {t.badge}
          {value === t.value && <span className="absolute inset-x-2 -bottom-px h-0.5 rounded bg-blue-500" />}
        </button>
      ))}
    </div>
  );
}
