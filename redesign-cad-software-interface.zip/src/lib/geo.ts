// Геодезическое ядро прототипа: парсер румбов, расчёт контура, проверки, соседи.
// Все функции чистые — легко переносятся в Python (llm_parser.py / acad_builder.py).

export type Seg = {
  ns: "N" | "S";
  deg: number;
  min: number;
  sec: number;
  ew: "E" | "W";
  len: number;
  /** позиция фрагмента в исходном тексте (для подсветки и правок) */
  start: number;
  end: number;
  lenStart: number;
  lenEnd: number;
};

export type Parsed = {
  segs: Seg[];
  mainStreet: string;
  crossStreet: string;
  tie: number;
};

export type Pt = { x: number; y: number };

export type Model = {
  segs: Seg[];
  az: number[]; // азимуты сторон (градусы, по часовой от севера)
  pts: Pt[]; // n+1 точек: v0..vn (vn — конец хода, при замыкании ≈ v0)
  crossing: Pt;
  pob: Pt;
  u: Pt; // единичный вектор главной улицы
  closure: number;
  area: number;
  perimeter: number;
  angles: number[]; // внутренние углы (градусы) в вершинах v0..v(n-1)
  outward: number; // знак нормали наружу (+1 | -1)
  mainStreet: string;
  crossStreet: string;
  tie: number;
};

export type Check = {
  id: string;
  level: "ok" | "warn" | "err";
  title: string;
  detail: string;
  sides: number[];
  fix?: { side: number; from: number; to: number; note: string };
};

const rad = (d: number) => (d * Math.PI) / 180;
const deg = (r: number) => (r * 180) / Math.PI;

export const segDeg = (s: Seg) => s.deg + s.min / 60 + s.sec / 3600;

export function azimuth(s: Seg) {
  const a = segDeg(s);
  if (s.ns === "N" && s.ew === "E") return a;
  if (s.ns === "S" && s.ew === "E") return 180 - a;
  if (s.ns === "S" && s.ew === "W") return 180 + a;
  return 360 - a;
}

export function fmtBearing(s: Seg) {
  const sec = Number.isInteger(s.sec) ? String(s.sec).padStart(2, "0") : s.sec.toFixed(1);
  return `${s.ns} ${s.deg}°${String(s.min).padStart(2, "0")}'${sec}" ${s.ew}`;
}

export function fmtDMS(d: number) {
  let t = Math.round(d * 3600);
  const D = Math.floor(t / 3600);
  t -= D * 3600;
  const M = Math.floor(t / 60);
  const S = t - M * 60;
  return `${D}°${String(M).padStart(2, "0")}'${String(S).padStart(2, "0")}"`;
}

export const fmtLen = (v: number) => `${v.toFixed(2)}'`;

const SEG_RE =
  /([NS])\s*(\d{1,3})\s*[°º]\s*(\d{1,2})\s*['′]\s*(?:(\d{1,2}(?:\.\d+)?)\s*(?:["″]|'')\s*)?([EW])[^\d]{0,60}?(\d+(?:\.\d+)?)\s*(?:feet|foot|ft|')/gi;

export function parseLegal(text: string): Parsed {
  const segs: Seg[] = [];
  SEG_RE.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = SEG_RE.exec(text))) {
    const full = m[0];
    const numStr = m[6];
    const lenEnd0 = m.index + full.search(new RegExp(numStr.replace(".", "\\.") + "\\s*(?:feet|foot|ft|')", "i")) + numStr.length;
    const lenStart0 = lenEnd0 - numStr.length;
    segs.push({
      ns: m[1].toUpperCase() as "N" | "S",
      deg: +m[2],
      min: +m[3],
      sec: m[4] ? +m[4] : 0,
      ew: m[5].toUpperCase() as "E" | "W",
      len: +numStr,
      start: m.index,
      end: m.index + full.length,
      lenStart: lenStart0,
      lenEnd: lenEnd0,
    });
  }
  const tieM = text.match(/(\d+(?:\.\d+)?)\s*(?:feet|ft)\s+(?:east|west|north|south)/i);
  const rowM = text.match(/line of\s+([A-Z][A-Za-z.\s]+?(?:Avenue|Street|Ave\.?|St\.?|Road|Rd\.?|Lane|Loop|Boulevard|Blvd\.?|Drive|Dr\.?))/i);
  const frontM = text.match(/side of\s+([A-Z][A-Za-z.\s]+?(?:Avenue|Street|Ave\.?|St\.?|Road|Rd\.?|Lane|Loop|Boulevard|Blvd\.?|Drive|Dr\.?))/i);
  return {
    segs,
    crossStreet: (rowM?.[1] ?? "CROSS STREET").trim().toUpperCase(),
    mainStreet: (frontM?.[1] ?? "MAIN STREET").trim().toUpperCase(),
    tie: tieM ? +tieM[1] : 0,
  };
}

export function buildModel(p: Parsed): Model | null {
  const { segs } = p;
  if (segs.length < 3) return null;
  const az = segs.map(azimuth);
  const u = { x: Math.sin(rad(az[0])), y: Math.cos(rad(az[0])) };
  const pob = { x: u.x * p.tie, y: u.y * p.tie };
  const pts: Pt[] = [pob];
  segs.forEach((s, i) => {
    const prev = pts[i];
    pts.push({ x: prev.x + s.len * Math.sin(rad(az[i])), y: prev.y + s.len * Math.cos(rad(az[i])) });
  });
  const last = pts[pts.length - 1];
  const closure = Math.hypot(last.x - pob.x, last.y - pob.y);
  let sa = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % pts.length];
    sa += a.x * b.y - b.x * a.y;
  }
  const area = Math.abs(sa) / 2;
  const ccw = sa > 0;
  const n = segs.length;
  const angles = segs.map((_, i) => {
    const prev = az[(i - 1 + n) % n];
    let turn = az[i] - prev; // правый поворот
    while (turn > 180) turn -= 360;
    while (turn < -180) turn += 360;
    return ccw ? 180 + turn : 180 - turn;
  });
  return {
    segs,
    az,
    pts,
    crossing: { x: 0, y: 0 },
    pob,
    u,
    closure,
    area,
    perimeter: segs.reduce((a, s) => a + s.len, 0),
    angles,
    outward: ccw ? 1 : -1,
    mainStreet: p.mainStreet,
    crossStreet: p.crossStreet,
    tie: p.tie,
  };
}

/** Внешняя нормаль стороны i (единичная) */
export function sideNormal(m: Model, i: number): Pt {
  const dx = Math.sin(rad(m.az[i]));
  const dy = Math.cos(rad(m.az[i]));
  // для CCW наружу = правая нормаль (dy,-dx); для CW — левая
  return m.outward === 1 ? { x: dy, y: -dx } : { x: -dy, y: dx };
}

function segIntersect(a: Pt, b: Pt, c: Pt, d: Pt) {
  const o = (p: Pt, q: Pt, r: Pt) => (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x);
  const d1 = o(a, b, c), d2 = o(a, b, d), d3 = o(c, d, a), d4 = o(c, d, b);
  return d1 * d2 < -1e-9 && d3 * d4 < -1e-9;
}

const SIMILAR = ["38", "80", "17", "56", "58", "06", "09", "14", "27", "69", "35"];
function similarDigitPair(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) {
      diff++;
      const pair = [a[i], b[i]].sort().join("");
      if (!SIMILAR.includes(pair)) return false;
    }
  }
  return diff === 1;
}

export function runChecks(m: Model): Check[] {
  const out: Check[] = [];
  const n = m.segs.length;

  // 1. Невязка
  out.push(
    m.closure <= 0.01
      ? { id: "closure", level: "ok", title: "Контур замкнут", detail: `Closure Error = ${m.closure.toFixed(3)} ft`, sides: [] }
      : {
          id: "closure",
          level: m.closure < 0.5 ? "warn" : "err",
          title: "Контур не замкнут",
          detail: `Closure Error = ${m.closure.toFixed(3)} ft. Гэп будет выведен в задний угол участка.`,
          sides: [n - 1],
        }
  );

  // 2. Сумма углов
  const sum = m.angles.reduce((a, b) => a + b, 0);
  const expect = (n - 2) * 180;
  out.push(
    Math.abs(sum - expect) < 1 / 3600
      ? { id: "angles", level: "ok", title: "Сумма внутренних углов", detail: `Σ∠ = ${fmtDMS(sum)} = (N−2)·180°`, sides: [] }
      : { id: "angles", level: "warn", title: "Сумма углов не сходится", detail: `Σ∠ = ${fmtDMS(sum)}, ожидалось ${fmtDMS(expect)}`, sides: [] }
  );

  // 3. Четырёхугольник: прямоугольность и противоположные стороны
  if (n === 4) {
    const maxDev = Math.max(...m.angles.map((a) => Math.abs(a - 90)));
    if (maxDev < 1 / 3600) {
      out.push({ id: "rect", level: "ok", title: "Углы прямые", detail: "Все 4 угла = 90°00'00\"", sides: [] });
    } else if (maxDev < 1) {
      out.push({
        id: "rect",
        level: "warn",
        title: "Почти прямоугольник",
        detail: `Углы отклоняются от 90° на ${fmtDMS(maxDev)} — проверьте минуты/секунды румбов`,
        sides: [0, 1, 2, 3],
      });
    }
    const par = (i: number, j: number) => {
      let d = Math.abs(m.az[i] - m.az[j]) % 360;
      if (d > 180) d = 360 - d;
      return Math.abs(d - 180) < 0.002;
    };
    for (const [i, j] of [[0, 2], [1, 3]] as const) {
      if (par(i, j)) {
        const a = m.segs[i].len, b = m.segs[j].len;
        if (Math.abs(a - b) > 0.005) {
          const sa = a.toFixed(2), sb = b.toFixed(2);
          const sim = similarDigitPair(sa.replace(".", ""), sb.replace(".", ""));
          const fixSide = Math.max(i, j);
          const keep = fixSide === i ? b : a;
          out.push({
            id: `opp${i}${j}`,
            level: "warn",
            title: `Стороны #${i + 1} и #${j + 1} параллельны, но длины разные`,
            detail: `${sa}' ≠ ${sb}'${sim ? " — похоже на опечатку визуально схожей цифры" : ""}. Вероятная правка: сторона #${fixSide + 1} → ${keep.toFixed(2)}'.`,
            sides: [i, j],
            fix: { side: fixSide, from: m.segs[fixSide].len, to: keep, note: sim ? "схожие цифры" : "парные стороны" },
          });
        }
      }
    }
  }

  // 4. Самопересечение
  let cross = false;
  for (let i = 0; i < n && !cross; i++)
    for (let j = i + 2; j < n; j++) {
      if (i === 0 && j === n - 1) continue;
      if (segIntersect(m.pts[i], m.pts[i + 1], m.pts[j], m.pts[j + 1])) {
        cross = true;
        out.push({ id: "self", level: "err", title: "Самопересечение контура", detail: `Стороны #${i + 1} и #${j + 1} пересекаются («песочные часы»)`, sides: [i, j] });
        break;
      }
    }
  if (!cross) out.push({ id: "self", level: "ok", title: "Самопересечений нет", detail: "Контур простой", sides: [] });

  // 5. Потеря точки / микросегменты
  const longIdx = m.segs.findIndex((s) => s.len > m.perimeter - s.len);
  if (longIdx >= 0)
    out.push({ id: "dec", level: "err", title: `Сторона #${longIdx + 1} длиннее суммы остальных`, detail: `${fmtLen(m.segs[longIdx].len)} — возможно потеряна десятичная точка`, sides: [longIdx] });
  const micro = m.segs.findIndex((s) => s.len < 0.5);
  if (micro >= 0)
    out.push({ id: "micro", level: "warn", title: `Микросегмент #${micro + 1}`, detail: `${fmtLen(m.segs[micro].len)} — вероятно артефакт распознавания`, sides: [micro] });

  return out;
}

// ───────────── Соседи ─────────────

export type Neighbor = {
  id: number;
  name: string;
  width: number;
  pts: Pt[]; // 4 точки
  level: "ok" | "warn";
  title: string;
  detail: string;
  wallSides: number; // индекс стороны основного, с которой стыкуется (первый сосед)
};

const NEIGHBOR_WIDTHS = [100, 80, 95, 110];

/** Строит очередного соседа стенка-к-стенке по стороне #2 основного участка. */
export function nextNeighbor(m: Model, list: Neighbor[]): Neighbor | null {
  if (m.segs.length < 3) return null;
  const k = list.length;
  const w = NEIGHBOR_WIDTHS[k % NEIGHBOR_WIDTHS.length];
  let a: Pt, d: Pt;
  let level: "ok" | "warn" = "ok";
  let title = "✓ межа совпадает";
  let detail = "";
  if (k === 0) {
    a = m.pts[1];
    const wallLen = m.segs[1].len;
    // у первого соседа стенка отличается на 8″ — демонстрация «клина»
    const wallAz = m.az[1] + 8 / 3600;
    d = { x: a.x + wallLen * Math.sin(rad(wallAz)), y: a.y + wallLen * Math.cos(rad(wallAz)) };
    const gap = Math.hypot(d.x - m.pts[2].x, d.y - m.pts[2].y);
    const wedge = 0.5 * wallLen * wallLen * rad(8 / 3600);
    level = "warn";
    title = "⚠ Δ∠ 8″ на общей меже";
    detail = `Румб стены у соседа S ${fmtDMS(180 - wallAz).replace(/^(\d+)/, "$1")} E против ${fmtBearing(m.segs[1])}. Клин: расхождение в конце стены ${gap.toFixed(4)} ft, площадь ≈ ${wedge.toFixed(3)} sq ft. Вероятно, ошибка OCR цифры секунд (0↔8) или округление 80-х.`;
  } else {
    const prev = list[k - 1];
    a = prev.pts[1];
    d = prev.pts[2];
    detail = `Общая стена ${fmtLen(Math.hypot(a.x - d.x, a.y - d.y))} — длина и румб совпадают.`;
  }
  const b = { x: a.x + w * m.u.x, y: a.y + w * m.u.y };
  const c = { x: d.x + w * m.u.x, y: d.y + w * m.u.y };
  return {
    id: k + 1,
    name: `Сосед #${k + 1}`,
    width: w,
    pts: [a, b, c, d],
    level,
    title,
    detail,
    wallSides: 1,
  };
}

export const hypot = Math.hypot;
export { rad, deg };
