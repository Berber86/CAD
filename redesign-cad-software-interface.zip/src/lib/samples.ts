export const SAMPLE_OK = `BEING a tract of land situated in the City of Austin, Travis County, Texas, being Lot 12, Block A, of the Smith Addition, according to the map or plat thereof recorded in Volume 5, Page 120, Plat Records of Travis County, Texas, and being more particularly described by metes and bounds as follows:

COMMENCING at a point in the East right-of-way line of Oak Avenue, being 150.00 feet East of the East line of Oak Avenue;

THENCE N 75°20'20" E, a distance of 120.00 feet to a point for corner;
THENCE S 14°39'40" E, a distance of 85.50 feet to a point for corner;
THENCE S 75°20'20" W, a distance of 120.00 feet to a point for corner;
THENCE N 14°39'40" W, a distance of 85.50 feet to the POINT OF BEGINNING.

Said tract fronts on the South side of Main Street and contains 10,260 square feet (0.2355 acres) of land, more or less.`;

export const SAMPLE_TYPO = SAMPLE_OK.replace("S 75°20'20\" W, a distance of 120.00", "S 75°20'20\" W, a distance of 126.00");
