export type Provider = "Hydra AI" | "OpenRouter" | "RouterAI";

export const MODELS: Record<Provider, string[]> = {
  "Hydra AI": ["glm-5.2", "hydra-gemini-pro", "hydra-gemini-3-pro", "hydra-gemini"],
  OpenRouter: ["nvidia/nemotron-3.5-super-vl:free", "nvidia/nemotron-3-super-120b-a12b:free", "stepfun/step-3.5-flash:free", "z-ai/glm-4.5-air:free"],
  RouterAI: ["openai/gpt-4.1", "openai/gpt-4.1-mini", "openai/gpt-4o", "google/gemini-2.5-pro", "google/gemini-2.5-flash", "anthropic/claude-sonnet-4.5", "deepseek/deepseek-chat"],
};

export type Slot = { provider: Provider; model: string };

export type Settings = {
  passes: 1 | 2 | 3;
  slots: [Slot, Slot, Slot];
  askOnDoubt: boolean;
  scale: 10 | 16 | 20 | 30;
  alwaysOnTop: boolean;
  sharpen: boolean;
  aiRotate: boolean;
  keys: Record<Provider, string>;
  pin: string;
};

export const DEFAULT_SETTINGS: Settings = {
  passes: 1,
  slots: [
    { provider: "Hydra AI", model: "glm-5.2" },
    { provider: "OpenRouter", model: "nvidia/nemotron-3.5-super-vl:free" },
    { provider: "RouterAI", model: "openai/gpt-4.1" },
  ],
  askOnDoubt: true,
  scale: 16,
  alwaysOnTop: false,
  sharpen: true,
  aiRotate: false,
  keys: { "Hydra AI": "", OpenRouter: "", RouterAI: "" },
  pin: "",
};

export type LogEntry = { t: string; level: "info" | "ok" | "warn" | "err"; msg: string };

export type Photo = { id: number; name: string; url: string; rot: number };

export type PassResult = {
  slot: number;
  label: string;
  model: string;
  closure: number;
  text: string; // исходный текст с правкой этого прохода
  diffs: { side: number; field: string; mine: string; other: string }[];
};

export type Role = "main" | "neighbor";
